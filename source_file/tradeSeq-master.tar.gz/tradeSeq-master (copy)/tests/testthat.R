library(testthat)
library(tradeSeq)
library(SingleCellExperiment)
library(slingshot)

test_check("tradeSeq")
