utils::globalVariables(names = c("i", "difference"),
                       package = 'rDBEC',
                       add = TRUE)

#' Demultiplex_DNAtags
#'
#' Demultiplex and annotate each cells by DNAtag count data based on Z scaling and pam clustering method.
#'
#' @param x A matrix or data.frame of DNAtag count data. first column represents cell ID, colnames represents Tag IDs.
#' @param object A Seurat v2 object created from genes and cells count data
#' @param nTags A number of DNA tags. must be an integer.
#' @param nCells_in_cartridge A number of cells loaded into Rhapsody cartridge. default=20000.
#' @param sample.name A name of sample
#' @param dir.name An output directory name for generate count threshold plots-containing folder
#' @param scale.max An upper limit of centered log2FC value for heatmap visualization. default=3
#' @param scale.min An lower limit of centered log2FC value for heatmap visualization. default=-3
#' @param prefix A character that add to the hashtag names (e.g. -ADT) default=NULL
#' @param scale.factor A global scale facotr for between-hashtag normalization. default=NULL (minimum read number of valid hashtags).
#'
#' @importFrom magrittr %>%
#'
#' @rdname Demultiplex_DNAtags
#' @return A list of Seurat object and demultiplex results ggplot object. Add TadID and Tagcount(first and second highest count) informations into meta.data slot. Also export plots and annotated tables.
#' @export

Demultiplex_DNAtags = function(x,
                               object,
                               nTags=3,
                               nCells_in_cartridge=20000,
                               sample.name="Sample1",
                               dir.name="./",
                               scale.max=3,
                               scale.min=-3,
                               prefix=NULL,
                               scale.factor = NULL

) {
  if (nTags <= 1){stop("must specify more than one Tags.")}

    data0=x[x$CellBC %in% rownames(object@meta.data), ]
  rownames(data0)=data0[,1]

  #pick up valid hashtag columns
  data0=data0[,2:ncol(data0)]
  data0=data0[,order(colSums(data0), decreasing = T)]
  data0=data0[,c(1:nTags)]
  data0=data0[,order(colnames(data0), decreasing = F)]

  #log-centered tag count data
  message("log2(x+1)-normalize hashtag count data by global scaling factor")
  #size factor is set as minimum summantion of each hashtag count
  #message("centered by log2 mean count")
  if (is.null(scale.factor)){
    data0  = sweep(data0, 2, STATS=min(colSums(data0)) / colSums(data0), FUN="*")
  } else {
    data0  = sweep(data0, 2, STATS=scale.factor / colSums(data0), FUN="*")
  }
  data1 = data0+1
  data1 = log2(data1)
  data1  = sweep(data1, 1, STATS=apply(data1,1,mean), FUN="-")
  data1=as.data.frame(data1)
  data1=stats::na.omit(data1)
  data1$first_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data1$second_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data1$difference = data1$first_most_probable - data1$second_most_probable

  #cut off probable doublets (because SN ratio is not visible)
  message("Detectable doublets will be assessed by Poisson's distribution")
  poisson_notEmpty = 1-stats::dpois(0, lambda=nCells_in_cartridge/200000)
  poisson_singlet = stats::dpois(1, lambda=nCells_in_cartridge/200000)
  pct.doublet = 1-poisson_singlet/poisson_notEmpty
  pct.doublet.detectable = pct.doublet*(choose(nTags+2-1, 2)-nTags)/choose(nTags+2-1, 2)
  pct_of_retain_cells = 1-pct.doublet.detectable

  message(paste("pct of retain cells is ", as.character(round(pct_of_retain_cells, digits=5)*100), "%", sep=''))
  #Must be mentioned that hashtags could only removes doublets derived from Rhapsody cell load step
  #message("Must be mentioned that hashtags could not remove remained doublet cells in the single-cell preparation (enzymatic digestion) step")
  #message("that could assess by FACS analysis. That is why, you must be removed these doublets manually by the expression pattern of marker genes")
  #data2 = data1[order(data1$difference, decreasing = T),]
  #data2 = data1[c(1:round(nrow(data1)*pct_of_retain_cells, digits=0)), ]
  data2 = cbind(rownames(data1), data1)

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
  #extract doublet data
  doublets = as.data.frame(data2) %>% dplyr::top_n(-round(nrow(data2)*pct.doublet.detectable, digits=0), difference)
  doublets = as.data.frame(doublets)
  rownames(doublets)=doublets[,1]
  doublets = doublets[,2:ncol(doublets)]
  doublets = doublets[,c(1:nTags)]
  #tmp = Matrix::rowSums(doublets) == 0
  tmp1 = rep("doublet", nrow(doublets))
  #tmp1[tmp]="not_detected"
  doublets = cbind(doublets, tmp1)
  colnames(doublets) = c(colnames(doublets)[1:nTags], "TagIDs")

  #extract no doublet data
  data2 = data1[setdiff(rownames(data1), rownames(doublets)), ]

  } else {
    message("no doublet could not detect in this experimental condition.")
  }

  #set limit of hashtag Fold-change
  if(nTags==2){
  clusters=data2[,1]
  clusters[clusters>0]=1
  clusters[clusters<0]=2
  names(clusters)=rownames(data2)
  } else{
  clusters = apply(data2[,c(1:nTags)], 1, function(x)(which.max(x)))
  names(clusters)=rownames(data2[,c(1:nTags)])
  }

  #reorder data of each cluster by hclust
  res1=NULL
  for (i in c(1:nTags)){
    tmp = data2[names(clusters[clusters==i]), c(1:nTags)]
    tmp=Matrix::t(scale(Matrix::t(tmp),center=TRUE))
    tmp[is.na(tmp)] = 0
    tmp[is.nan(tmp)] = 0
    if(nrow(tmp)>2){
    tmp2 =stats::hclust(stats::dist(tmp, method = "euclidean"), method="ward.D")
    tmp = tmp[tmp2$order,]
    }
    tmp1 = colMeans(tmp)
    names(tmp1)=colnames(tmp)
    tmp = as.data.frame(tmp)
    tmp1=sort(tmp1, decreasing = T)
    tmp3=rep(names(tmp1[1]), nrow(tmp))
    tmp[tmp>scale.max] = scale.max
    tmp[tmp<scale.min] = scale.min
    tmp=cbind(tmp, tmp3)
    colnames(tmp)=c(colnames(tmp)[1:nTags], "TagIDs")
    tmp$TagIDs = as.character(tmp$TagIDs)
    res1 = rbind(res1, tmp)
  }

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
    temp = doublets[,c(1:nTags)]
    temp=Matrix::t(scale(Matrix::t(temp),center=TRUE))
    temp[is.na(temp)] = 0
    temp[is.nan(temp)] = 0
    if(nrow(doublets)>2){
    tmp2 =stats::hclust(stats::dist(temp, method = "euclidean"), method="ward.D")
    }
    temp[temp>scale.max] = scale.max
    temp[temp<scale.min] = scale.min
    temp = as.data.frame(temp)
    if(nrow(doublets)>2){
    doublets = cbind(temp[tmp2$order,], doublets[tmp2$order,"TagIDs", drop=F])
    } else {
    doublets = cbind(temp, doublets[,"TagIDs", drop=F])
    }
    colnames(doublets)=c(colnames(temp), "TagIDs")
    doublets$TagIDs = as.character(doublets$TagIDs)
    doublets = as.data.frame(doublets)
  }

  file.name = sprintf("%s_demultiplex.txt", sample.name)
  file.name = paste(dir.name, file.name, sep='')

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
    res1=rbind(res1, doublets)
  }
  data.table::fwrite(res1, file.name, sep="\t", quote=F, row.names=T, col.names=T)


  cluster_annot = res1[,"TagIDs",drop=F]
  cluster_annot[,1] = as.character(cluster_annot[,1])
  colnames(cluster_annot) = "TagIDs"

  message("draw demultiplex heatmap...")
  cluster_palette = c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c',
                      '#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',
                      '#49beaa', '#611c35', '#2708a0')
  cluster_colors = cluster_palette[1:length(unique(cluster_annot[,1]))]
  names(cluster_colors) = sort(unique(cluster_annot[,1]))

  annotation_row = cluster_annot
  rownames(annotation_row) = rownames(res1)
  annotation_colors = list(
    TagIDs=cluster_colors
  )

  res1=res1[order(res1$TagIDs, decreasing=F),]

  bks = seq(scale.min-0.1, scale.max+0.1, by = 0.1)
  cols = grDevices::colorRampPalette(c("blue","cyan","white","magenta", "red"))
  brcols=cols(length(bks))
  p = pheatmap::pheatmap(
    res1[,c(1:nTags)],
    scale="none",
    cluster_rows=FALSE,
    cluster_cols=FALSE,
    show_colnames=FALSE,
    show_rownames=FALSE,
    annotation_row=annotation_row,
    annotation_colors = annotation_colors,
    annotation_names_row=FALSE,
    color=brcols,
    breaks = bks,
    border_color = NA,
    main="log2 centered count"
  )
  p = ggplotify::as.ggplot(p[[4]])

  if (is.null(prefix)){
    file.name=sample.name
  } else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_demultiplex.png", file.name)
  file.name = paste(dir.name, file.name, sep='')
  ggplot2::ggsave(file.name, p, device="png", units="in", dpi = 300, width = 5, height = 6, limitsize=FALSE)
  grDevices::dev.off()

  message("add hashtag/sampletag/Abtag information to Seurat metadata...")

  if (object@version == "2.3.4"){
    raw.data = object@raw.data
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  } else if (object@version >= "3.0"){
    raw.data = GetAssayData(object, slot = "counts", assay="RNA")
    if (nrow(raw.data) == 0){stop(message("could not retrive raw count matrix from Seurat object. STOP"))}
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  }

  annot = as.character(res1[rownames(res1) %in% colnames(raw.data),"TagIDs"])
  names(annot)=rownames(res1[rownames(res1) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = as.character(rep("not_detected",length(not_annotated_cell)))
    names(annot_NA)=setdiff(colnames(raw.data), rownames(data1))
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="TagIDs"
  } else {
    slot.name = paste("TagIDs", "-", prefix, sep = "")
  }
  object = AddMetaData(object = object, metadata = annot, col.name = slot.name)


  # add each normalized hashtag reads into Seurat metadata
  for (i in c(1:nTags)){

  hashtag_name = colnames(data0)[i]
  hashtag_name = paste(hashtag_name, ".log2", sep = "")
  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),i])
  annot = log2(annot+1)
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])
    if (length(not_annotated_cell) > 0){
     annot_NA = rep(0,length(not_annotated_cell))
     names(annot_NA)=not_annotated_cell
     annot = c(annot, annot_NA)
    }
  object = Seurat::AddMetaData(object = object, metadata = annot, col.name = hashtag_name)

  }

  # add first and second probable hashtag reads into Seurat metadata
  data0$first_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data0$second_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))

  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),"first_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
  slot.name="first_most_probable_TagReads"
  } else {
  slot.name = paste("first_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = Seurat::AddMetaData(object = object, metadata = annot, col.name = slot.name)

  annot = as.character(data0[rownames(data0) %in% colnames(raw.data),"second_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="second_most_probable_TagReads"
  } else {
    slot.name = paste("second_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = Seurat::AddMetaData(object = object, metadata = annot, col.name = slot.name)

  res = list()
  res[[1]]=object
  res[[2]]=p
  return(res)
}

utils::globalVariables(names = c("i", "difference","Var1", "Var2", "A", "B", "first_most_probable", "second_most_probable",
                                 "classification"),
                       package = 'rDBEC',
                       add = TRUE)

#' Demultiplex_DNAtags2
#'
#' Demultiplex and annotate each cells by Tag count data. Doublets (Tag DP cells) are detected by using flowDensity package.
#'
#' @param x A matrix or data.frame of DNAtag count data. first column represents cell ID, colnames represents Tag IDs.
#' @param object A Seurat v2 object created from genes and cells count data
#' @param nTags A number of DNA tags. must be an integer.
#' @param sample.name A name of sample
#' @param dir.name An output directory name for generate count threshold plots-containing folder
#' @param scale.max An upper limit of centered log2FC value for heatmap visualization. default=3
#' @param scale.min An lower limit of centered log2FC value for heatmap visualization. default=-3
#' @param prefix A character that add to the hashtag names (e.g. -ADT) default=NULL
#' @param scale.factor A global scale facotr for between-hashtag normalization. default=NULL (minimum read number of valid hashtags).
#' @param floor A threshold that minimum tag expression level after logicle transformation. default=5.
#'
#' @importFrom magrittr %>%
#'
#' @rdname Demultiplex_DNAtags2
#' @return A list of Seurat object, demultiplex result heatmap, and scatter plot for doublet identification. Add TagID and Tagcount(first and second highest count) informations into meta.data slot. Also export plots and annotated tables.
#' @export

Demultiplex_DNAtags2 = function(x,
                               object,
                               nTags=3,
                               sample.name="Sample1",
                               dir.name="./",
                               scale.max=3,
                               scale.min=-3,
                               prefix=NULL,
                               scale.factor = NULL,
                               floor = 5

) {
  if (nTags <= 1){stop("must specify more than one Tags.")}

    data0=x[x$CellBC %in% rownames(object@meta.data), ]

  rownames(data0)=data0[,1]

  #pick up valid hashtag columns
  data0=data0[,2:ncol(data0)]
  data0=data0[,order(colSums(data0), decreasing = T)]
  data0=data0[,c(1:nTags)]
  data0=data0[,order(colnames(data0), decreasing = F)]

  #log-centered tag count data
  message(paste0("normalize hashtag count data by global scaling factor as ", 10000000))
  #size factor is set as minimum summantion of each hashtag count
  message("Perform global normalization")
  if (is.null(scale.factor)){
    data0  = sweep(data0, 2, STATS=10000000 / colSums(data0), FUN="*")
  } else {
    data0  = sweep(data0, 2, STATS=scale.factor / colSums(data0), FUN="*")
  }

  #set fold-change threshold based on poisson distribution
  message("Tag fold-change threshold was assessed based on Poisson's distribution")
  poisson_notEmpty = 1-stats::dpois(0, lambda=nrow(data0)/200000)
  poisson_singlet = stats::dpois(1, lambda=nrow(data0)/200000)
  pct.doublet = 1-poisson_singlet/poisson_notEmpty
  pct.doublet.detectable = pct.doublet*(choose(nTags+2-1, 2)-nTags)/choose(nTags+2-1, 2)
  pct_of_retain_cells = 1- pct.doublet.detectable
  data_tmp = data0+1
  data_tmp = log2(data_tmp)
  #data_tmp  = sweep(data_tmp, 1, STATS=apply(data_tmp,1,mean), FUN="-")
  #data_tmp=as.data.frame(data_tmp)
  #data_tmp=stats::na.omit(data_tmp)
  data_tmp$first_most_probable = unlist(apply(data_tmp[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data_tmp$second_most_probable = unlist(apply(data_tmp[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data_tmp$difference = data_tmp$first_most_probable - data_tmp$second_most_probable


  if (round(nrow(data_tmp)*pct_of_retain_cells, digits=0) != nrow(data_tmp)){
    #extract doublet data
    hoge = as.data.frame(data_tmp) %>% dplyr::top_n(-round(nrow(data_tmp)*pct.doublet.detectable, digits=0), difference)
    min.fc = max(hoge$difference)
  } else {
    min.fc = 0.4
  }
  message(paste0("minimum log2 fold-change between first- and second-most probable Tag is ", round(min.fc, digits=5)))
  message("Detect doublets by flowDensity Package")

  #create list of the tag pairs
  channel_list=base::expand.grid(colnames(data0), colnames(data0))
  channel_list=base::subset(channel_list, unclass(Var1) < unclass(Var2))
  channel_name=colnames(data0)

  #detect tag-DP cells by flowDensity package
  DP_index = list()
  p_list = list()

  for (i in c(1:nrow(channel_list))){
    channels = channel_name[as.numeric(channel_list[i,])] #select Tag pair name

    tmp_ff = as.matrix(data0)[,as.numeric(channel_list[i,])]

    #filter out cells that any of tag expression under certain threshold to detect double-positive cells correctly

    tmp_ff2 = tmp_ff[tmp_ff[,1]>floor,]
    tmp_ff2 = tmp_ff2[tmp_ff2[,2]>floor,]
    ff = flowCore::flowFrame(as.matrix(tmp_ff2))

    #perform logicle transformation
    trans = flowCore::estimateLogicle(ff, channels =channels)
    ff = flowCore::transform(ff, trans)

    #poligon gate, detect single-positive/double-negative cells separately
    #SP.1 = flowDensity(obj=ff, channels = channels, position=c(TRUE, FALSE), ellip.gate=TRUE)
    #SP.2 = flowDensity(obj=ff, channels = channels, position=c(FALSE, TRUE), ellip.gate=TRUE)
    #DN.1 = flowDensity(obj=ff, channels = channels, position=c(FALSE, FALSE))
    DP.1 = flowDensity::flowDensity(obj=ff, channels = channels, position=c(TRUE, TRUE))

    fuga = as.data.frame(ff@exprs)
    fuga = fuga[,channels]
    colnames(fuga)=c("A", "B")

    gate = as.data.frame(DP.1@filter)
    gate = gate[,channels]
    colnames(gate)=c("A", "B")

    p = ggplot2::ggplot(fuga) +
      ggplot2::geom_hex(aes(A, B),
               bins = 75,
               show.legend = TRUE) +
      ggplot2::scale_fill_gradientn("", colours = rev(grDevices::rainbow(10, end = 3.5/6))) +
      ggplot2::geom_polygon(data=gate, aes(A, B), colour="magenta", alpha=0.2) +
      ggplot2::theme_linedraw() +
      ggplot2::xlab(channels[1]) + ggplot2::ylab(channels[2]) +
      ggplot2::theme(legend.position='none', axis.text = element_text(size=8), axis.title = element_text(size=8))

    #save DP cells (doublet cells) ID
    DP_index[[i]] = rownames(tmp_ff2)[DP.1@index]
    p_list[[i]] = p
  }

  #annotate doublets
  DP_index = unlist(DP_index)
  DP_index = unique(DP_index)

  if(length(DP_index)>0){
  DP_cells = rep("doublet", length(DP_index))
  names(DP_cells)=DP_index
  #filter out doublets
  data1 = data0[!rownames(data0) %in% DP_index,]
  doublets = data0[rownames(data0) %in% DP_index,]
  } else {
    message("no doublets detected")
    data1 = data0
    doublets =NULL
  }

  #assign each tags to each cells by fold change between first- and second most-expressed Tags
  data1 = log2(data1+1)
  #data1  = sweep(data1, 1, STATS=apply(data1,1,mean), FUN="-")
  #data1=as.data.frame(data1)
  #data1=stats::na.omit(data1)
  data1$first_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data1$second_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data1$difference = data1$first_most_probable - data1$second_most_probable

  #cut off ambiguous cells by fold-change
  ambiguous = data1[data1$difference <= min.fc,c(1:nTags)]
  doublets = rbind(doublets, ambiguous)
  tmp1 = rep("doublet", nrow(doublets))
  doublets = cbind(doublets, tmp1)
  colnames(doublets) = c(colnames(doublets)[1:nTags], "TagIDs")

  fuga = log2(data0+1)
  fuga$first_most_probable = unlist(apply(fuga[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  fuga$second_most_probable = unlist(apply(fuga[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))
  fuga1 = fuga[rownames(fuga) %in% rownames(doublets),]
  fuga2 = fuga[!rownames(fuga) %in% rownames(doublets),]

  fuga1$classification =  rep("doublet", nrow(fuga1))
  fuga2$classification =  rep("singlet", nrow(fuga2))
  fuga = rbind(fuga1, fuga2)

  #visualize doublets
  p2 = ggplot2::ggplot(fuga, aes(x=first_most_probable, y=second_most_probable, color=classification)) +
    ggplot2::geom_point(size=0.2)+
    ggplot2::theme_linedraw() +
    ggplot2::theme(axis.text = element_text(size=8), axis.title = element_text(size=8))

  p2_legend = cowplot::get_legend(p2)
  p2 = p2 + ggplot2::theme(legend.position='none')
  p_list[[nrow(channel_list)+1]]=p2
  p_list[[nrow(channel_list)+2]]=p2_legend

  p_doublet = cowplot::plot_grid(plotlist=p_list, ncol=4) + ggplot2::ggtitle("Doublet identification") +
    ggplot2::theme(plot.title=element_text(hjust = 0.5), text=element_text(size=10))
  if (is.null(prefix)){
    file.name=sample.name
  } else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_doubletIdentification.png", file.name)
  file.name = paste(dir.name, file.name, sep='')

  ggplot2::ggsave(file.name, plot=p_doublet, device="png", units="in",
                  width = 6, height=1.5 * ceiling(length(p_list)/4), dpi = 300)

  data1 = data1[data1$difference > min.fc,]
  data2 = data1

  #set limit of hashtag Fold-change
  #if(nTags==2){
  #  clusters=data2[,1]
  #  clusters[clusters>0]=1
  #  clusters[clusters<0]=2
  #  names(clusters)=rownames(data2)
  #} else{
    clusters = apply(data2[,c(1:nTags)], 1, function(x)(which.max(x)))
    names(clusters)=rownames(data2[,c(1:nTags)])
  #}

  #reorder data of each cluster by hclust
  res1=NULL
  for (i in c(1:nTags)){
    tmp = data2[names(clusters[clusters==i]), c(1:nTags)]
    tmp=Matrix::t(scale(Matrix::t(tmp),center=TRUE))
    tmp[is.na(tmp)] = 0
    tmp[is.nan(tmp)] = 0
    if(nrow(tmp)>2){
      tmp2 =stats::hclust(stats::dist(tmp, method = "euclidean"), method="ward.D")
      tmp = tmp[tmp2$order,]
    }
    tmp1 = colMeans(tmp)
    names(tmp1)=colnames(tmp)
    tmp = as.data.frame(tmp)
    tmp1=sort(tmp1, decreasing = T)
    tmp3=rep(names(tmp1[1]), nrow(tmp))
    tmp[tmp>scale.max] = scale.max
    tmp[tmp<scale.min] = scale.min
    tmp=cbind(tmp, tmp3)
    colnames(tmp)=c(colnames(tmp)[1:nTags], "TagIDs")
    tmp$TagIDs = as.character(tmp$TagIDs)
    res1 = rbind(res1, tmp)
  }

  if(length(DP_index)>0){
    temp = doublets[,c(1:nTags)]
    temp=Matrix::t(scale(Matrix::t(temp),center=TRUE))
    temp[is.na(temp)] = 0
    temp[is.nan(temp)] = 0
    if(nrow(doublets)>2){
      tmp2 =stats::hclust(stats::dist(temp, method = "euclidean"), method="ward.D")
    }
    temp[temp>scale.max] = scale.max
    temp[temp<scale.min] = scale.min
    temp = as.data.frame(temp)
    if(nrow(doublets)>2){
      doublets = cbind(temp[tmp2$order,], doublets[tmp2$order,"TagIDs", drop=F])
    } else {
      doublets = cbind(temp, doublets[,"TagIDs", drop=F])
    }
    colnames(doublets)=c(colnames(temp), "TagIDs")
    doublets$TagIDs = as.character(doublets$TagIDs)
    doublets = as.data.frame(doublets)
  }

  file.name = sprintf("%s_demultiplex.txt", sample.name)
  file.name = paste(dir.name, file.name, sep='')

  if(length(DP_index)>0){
    res1=rbind(res1, doublets)
  }
  data.table::fwrite(res1, file.name, sep="\t", quote=F, row.names=T, col.names=T)


  cluster_annot = res1[,"TagIDs",drop=F]
  cluster_annot[,1] = as.character(cluster_annot[,1])
  colnames(cluster_annot) = "TagIDs"

  message("draw demultiplex heatmap...")
  cluster_palette = c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c',
                      '#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',
                      '#49beaa', '#611c35', '#2708a0')
  cluster_colors = cluster_palette[1:length(unique(cluster_annot[,1]))]
  names(cluster_colors) = sort(unique(cluster_annot[,1]))

  annotation_row = cluster_annot
  rownames(annotation_row) = rownames(res1)
  annotation_colors = list(
    TagIDs=cluster_colors
  )

  res1=res1[order(res1$TagIDs, decreasing=F),]

  bks = seq(scale.min-0.1, scale.max+0.1, by = 0.1)
  cols = grDevices::colorRampPalette(c("blue","cyan","white","magenta", "red"))
  brcols=cols(length(bks))
  p = pheatmap::pheatmap(
    res1[,c(1:nTags)],
    scale="none",
    cluster_rows=FALSE,
    cluster_cols=FALSE,
    show_colnames=FALSE,
    show_rownames=FALSE,
    annotation_row=annotation_row,
    annotation_colors = annotation_colors,
    annotation_names_row=FALSE,
    color=brcols,
    breaks = bks,
    border_color = NA,
    main="log2 centered count"
  )
  p = ggplotify::as.ggplot(p[[4]])

  if (is.null(prefix)){
    file.name=sample.name
  } else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_demultiplex.png", file.name)
  file.name = paste(dir.name, file.name, sep='')
  ggplot2::ggsave(file.name, p, device="png", units="in", dpi = 300, width = 5, height = 6, limitsize=FALSE)
  grDevices::dev.off()

  message("add hashtag/sampletag/Abtag information to Seurat metadata...")

  if (object@version == "2.3.4"){
    raw.data = object@raw.data
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  } else if (object@version >= "3.0"){
    raw.data = GetAssayData(object, slot = "counts", assay="RNA")
    if (nrow(raw.data) == 0){stop(message("could not retrive raw count matrix from Seurat object. STOP"))}
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  }

  annot = as.character(res1[rownames(res1) %in% colnames(raw.data),"TagIDs"])
  names(annot)=rownames(res1[rownames(res1) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = as.character(rep("not-detected",length(not_annotated_cell)))
    names(annot_NA)=setdiff(colnames(raw.data), rownames(data1))
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="TagIDs"
  } else {
    slot.name = paste("TagIDs", "-", prefix, sep = "")
  }
  object = AddMetaData(object = object, metadata = annot, col.name = slot.name)


  # add each normalized hashtag reads into Seurat metadata
  for (i in c(1:nTags)){

    hashtag_name = colnames(data0)[i]
    hashtag_name = paste(hashtag_name, ".log2", sep = "")
    annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),i])
    annot = log2(annot+1)
    names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])
    if (length(not_annotated_cell) > 0){
      annot_NA = rep(0,length(not_annotated_cell))
      names(annot_NA)=not_annotated_cell
      annot = c(annot, annot_NA)
    }
    object = Seurat::AddMetaData(object = object, metadata = annot, col.name = hashtag_name)

  }

  # add first and second probable hashtag reads into Seurat metadata
  data0$first_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data0$second_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))

  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),"first_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="first_most_probable_TagReads"
  } else {
    slot.name = paste("first_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = Seurat::AddMetaData(object = object, metadata = annot, col.name = slot.name)

  annot = as.character(data0[rownames(data0) %in% colnames(raw.data),"second_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="second_most_probable_TagReads"
  } else {
    slot.name = paste("second_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = Seurat::AddMetaData(object = object, metadata = annot, col.name = slot.name)

  res = list()
  res[[1]]=object
  res[[2]]=p
  res[[3]]=p_doublet
  res[[4]]=round(min.fc, digits=5)
  res[[5]]=length(p_list)
  return(res)
}


utils::globalVariables(names = c("i", "difference","Var1", "Var2", "A", "B", "first_most_probable", "second_most_probable",
                                 "classification"),
                       package = 'rDBEC',
                       add = TRUE)

#' Demultiplex_DNAtags3
#'
#' Demultiplex and annotate each cells by Tag count data. Doublets (Tag DP cells) are detected by using flowDensity package.
#'
#' @param x A matrix or data.frame of DNAtag count data. first column represents cell ID, colnames represents Tag IDs.
#' @param object A Seurat v2 object created from genes and cells count data
#' @param nTags A number of DNA tags. must be an integer.
#' @param sample.name A name of sample
#' @param dir.name An output directory name for generate count threshold plots-containing folder
#' @param scale.max An upper limit of centered log2FC value for heatmap visualization. default=3
#' @param scale.min An lower limit of centered log2FC value for heatmap visualization. default=-3
#' @param prefix A character that add to the hashtag names (e.g. -ADT) default=NULL
#' @param scale.factor A global scale facotr for between-hashtag normalization. default=NULL (minimum read number of valid hashtags).
#' @param floor A threshold that minimum tag expression level after logicle transformation. default=5.
#' @param max.DP.cells A threshold that expected maximum rate of Tag-double positive cells. default=0.05.
#'
#' @importFrom magrittr %>%
#'
#' @rdname Demultiplex_DNAtags3
#' @return A list of Seurat object, demultiplex result heatmap, and scatter plot for doublet identification. Add TagID and Tagcount(first and second highest count) informations into meta.data slot. Also export plots and annotated tables.
#' @export

Demultiplex_DNAtags3 = function (x, object, nTags = 3, sample.name = "Sample1", dir.name = "./",
                                 scale.max = 3, scale.min = -3, prefix = NULL, scale.factor = NULL,
                                 floor = 5, max.DP.cells=0.05)
{
  if (nTags <= 1) {
    stop("must specify more than one Tags.")
  }
  data0 = x[x$CellBC %in% rownames(object@meta.data), ]
  rownames(data0) = data0[, 1]
  data0 = data0[, 2:ncol(data0)]
  data0 = data0[, order(colSums(data0), decreasing = T)]
  data0 = data0[, c(1:nTags)]
  data0 = data0[, order(colnames(data0), decreasing = F)]
  message(paste0("normalize hashtag count data by global scaling factor as ",
                 1e+07))
  message("Perform global normalization")
  if (is.null(scale.factor)) {
    data0 = sweep(data0, 2, STATS = 1e+07/colSums(data0),
                  FUN = "*")
  }
  else {
    data0 = sweep(data0, 2, STATS = scale.factor/colSums(data0),
                  FUN = "*")
  }
  message("Tag fold-change threshold was assessed based on Poisson's distribution")
  poisson_notEmpty = 1 - stats::dpois(0, lambda = nrow(data0)/2e+05)
  poisson_singlet = stats::dpois(1, lambda = nrow(data0)/2e+05)
  pct.doublet = 1 - poisson_singlet/poisson_notEmpty
  pct.doublet.detectable = pct.doublet * (choose(nTags + 2 -
                                                   1, 2) - nTags)/choose(nTags + 2 - 1, 2)
  pct_of_retain_cells = 1 - pct.doublet.detectable
  data_tmp = data0 + 1
  data_tmp = log2(data_tmp)
  data_tmp$first_most_probable = unlist(apply(data_tmp[, c(1:nTags)],
                                              1, FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data_tmp$second_most_probable = unlist(apply(data_tmp[,
                                                        c(1:nTags)], 1, FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data_tmp$difference = data_tmp$first_most_probable - data_tmp$second_most_probable
  if (round(nrow(data_tmp) * pct_of_retain_cells, digits = 0) !=
      nrow(data_tmp)) {
    hoge = as.data.frame(data_tmp) %>% dplyr::top_n(-round(nrow(data_tmp) *
                                                             pct.doublet.detectable, digits = 0), difference)
    min.fc = max(hoge$difference)
  }
  else {
    min.fc = 0.4
  }
  message(paste0("minimum log2 fold-change between first- and second-most probable Tag is ",
                 round(min.fc, digits = 5)))
  message("Detect doublets by flowDensity Package")
  channel_list = base::expand.grid(colnames(data0), colnames(data0))
  channel_list = base::subset(channel_list, unclass(Var1) <
                                unclass(Var2))
  channel_name = colnames(data0)
  DP_index = list()
  p_list = list()
  for (i in c(1:nrow(channel_list))) {
    channels = channel_name[as.numeric(channel_list[i, ])]
    tmp_ff = as.matrix(data0)[, as.numeric(channel_list[i,
    ])]
    tmp_ff2 = tmp_ff[tmp_ff[, 1] > floor, ]
    tmp_ff2 = tmp_ff2[tmp_ff2[, 2] > floor, ]
    ff = flowCore::flowFrame(as.matrix(tmp_ff2))
    trans = flowCore::estimateLogicle(ff, channels = channels)
    ff = flowCore::transform(ff, trans)

    #remove lower 10% quantile

    fuga1 = as.data.frame(ff@exprs)
    rownames(fuga1)=rownames(tmp_ff2)
    quantile_threshold=0.1
    q1 = quantile(fuga1[,1], probs=c(quantile_threshold, 0.9))
    q2 = quantile(fuga1[,2], probs=c(quantile_threshold, 0.9))
    fuga1 = fuga1[fuga1[, 1] > q1[1], ]
    fuga1 = fuga1[fuga1[, 2] > q2[1], ]
    ff2 = flowCore::flowFrame(as.matrix(fuga1))
    DP.1 = quiet(flowDensity::flowDensity(obj = ff2, channels = channels,
                                          position = c(TRUE, TRUE)))

    doublet_Number = length(DP.1@index)
    while(doublet_Number / nrow(tmp_ff2) >= max.DP.cells){
      quantile_threshold = quantile_threshold + 0.05
      fuga1 = as.data.frame(ff@exprs)
      q1 = quantile(fuga1[,1], probs=c(quantile_threshold, 0.9))
      q2 = quantile(fuga1[,2], probs=c(quantile_threshold, 0.9))
      fuga1 = fuga1[fuga1[, 1] > q1[1], ]
      fuga1 = fuga1[fuga1[, 2] > q2[1], ]
      ff2 = flowCore::flowFrame(as.matrix(fuga1))
      DP.1 = quiet(flowDensity::flowDensity(obj = ff2, channels = channels,
                                            position = c(TRUE, TRUE)))
      doublet_Number = length(DP.1@index)
    }

    gate = as.data.frame(DP.1@filter)
    gate = gate[, channels]
    colnames(gate) = c("A", "B")

    mat_draw = as.data.frame(ff@exprs)
    colnames(mat_draw)= c("A", "B")
    mat_draw=as.data.frame(mat_draw)
    p = ggplot2::ggplot(mat_draw) + ggplot2::geom_hex(aes(A,
                                                          B), bins = 75, show.legend = TRUE) +
      ggplot2::scale_fill_gradientn("", colours = rev(grDevices::rainbow(10, end = 3.5/6))) +
      ggplot2::geom_polygon(data = gate, aes(A, B), colour = "magenta",
                            alpha = 0.2) + ggplot2::theme_linedraw() + ggplot2::xlab(channels[1]) +
      ggplot2::ylab(channels[2]) + ggplot2::theme(legend.position = "none",
                                                  axis.text = element_text(size = 8), axis.title = element_text(size = 8))
    DP_index[[i]] = rownames(fuga1)[DP.1@index]
    p_list[[i]] = p
  }
  DP_index = unlist(DP_index)
  DP_index = unique(DP_index)
  if (length(DP_index) > 0) {
    DP_cells = rep("doublet", length(DP_index))
    names(DP_cells) = DP_index
    data1 = data0[!rownames(data0) %in% DP_index, ]
    doublets = data0[rownames(data0) %in% DP_index, ]
  }
  else {
    message("no doublets detected")
    data1 = data0
    doublets = NULL
  }
  data1 = log2(data1 + 1)
  data1$first_most_probable = unlist(apply(data1[, c(1:nTags)],
                                           1, FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data1$second_most_probable = unlist(apply(data1[, c(1:nTags)],
                                            1, FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data1$difference = data1$first_most_probable - data1$second_most_probable
  ambiguous = data1[data1$difference <= min.fc, c(1:nTags)]
  doublets = rbind(doublets, ambiguous)
  tmp1 = rep("doublet", nrow(doublets))
  doublets = cbind(doublets, tmp1)
  colnames(doublets) = c(colnames(doublets)[1:nTags], "TagIDs")
  fuga = log2(data0 + 1)
  fuga$first_most_probable = unlist(apply(fuga[, c(1:nTags)],
                                          1, FUN = function(x) sort(x, decreasing = TRUE)[1]))
  fuga$second_most_probable = unlist(apply(fuga[, c(1:nTags)],
                                           1, FUN = function(x) sort(x, decreasing = TRUE)[2]))
  fuga1 = fuga[rownames(fuga) %in% rownames(doublets), ]
  fuga2 = fuga[!rownames(fuga) %in% rownames(doublets), ]
  fuga1$classification = rep("doublet", nrow(fuga1))
  fuga2$classification = rep("singlet", nrow(fuga2))
  fuga = rbind(fuga1, fuga2)
  p2 = ggplot2::ggplot(fuga, aes(x = first_most_probable,
                                 y = second_most_probable, color = classification)) +
    ggplot2::geom_point(size = 0.2) + ggplot2::theme_linedraw() +
    ggplot2::theme(axis.text = element_text(size = 8), axis.title = element_text(size = 8))
  p2_legend = cowplot::get_legend(p2)
  p2 = p2 + ggplot2::theme(legend.position = "none")
  p_list[[nrow(channel_list) + 1]] = p2
  p_list[[nrow(channel_list) + 2]] = p2_legend
  p_doublet = cowplot::plot_grid(plotlist = p_list, ncol = 4) +
    ggplot2::ggtitle("Doublet identification") + ggplot2::theme(plot.title = element_text(hjust = 0.5),
                                                                text = element_text(size = 10))
  if (is.null(prefix)) {
    file.name = sample.name
  }
  else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_doubletIdentification.png", file.name)
  file.name = paste(dir.name, file.name, sep = "")
  ggplot2::ggsave(file.name, plot = p_doublet, device = "png",
                  units = "in", width = 6, height = 1.5 * ceiling(length(p_list)/4),
                  dpi = 300)
  data1 = data1[data1$difference > min.fc, ]
  data2 = data1
  clusters = apply(data2[, c(1:nTags)], 1, function(x) (which.max(x)))
  names(clusters) = rownames(data2[, c(1:nTags)])
  res1 = NULL
  for (i in c(1:nTags)) {
    tmp = data2[names(clusters[clusters == i]), c(1:nTags)]
    tmp = Matrix::t(scale(Matrix::t(tmp), center = TRUE))
    tmp[is.na(tmp)] = 0
    tmp[is.nan(tmp)] = 0
    if (nrow(tmp) > 2) {
      tmp2 = stats::hclust(stats::dist(tmp, method = "euclidean"),
                           method = "ward.D")
      tmp = tmp[tmp2$order, ]
    }
    tmp1 = colMeans(tmp)
    names(tmp1) = colnames(tmp)
    tmp = as.data.frame(tmp)
    tmp1 = sort(tmp1, decreasing = T)
    tmp3 = rep(names(tmp1[1]), nrow(tmp))
    tmp[tmp > scale.max] = scale.max
    tmp[tmp < scale.min] = scale.min
    tmp = cbind(tmp, tmp3)
    colnames(tmp) = c(colnames(tmp)[1:nTags], "TagIDs")
    tmp$TagIDs = as.character(tmp$TagIDs)
    res1 = rbind(res1, tmp)
  }
  if (length(DP_index) > 0) {
    temp = doublets[, c(1:nTags)]
    temp = Matrix::t(scale(Matrix::t(temp), center = TRUE))
    temp[is.na(temp)] = 0
    temp[is.nan(temp)] = 0
    if (nrow(doublets) > 2) {
      tmp2 = stats::hclust(stats::dist(temp, method = "euclidean"),
                           method = "ward.D")
    }
    temp[temp > scale.max] = scale.max
    temp[temp < scale.min] = scale.min
    temp = as.data.frame(temp)
    if (nrow(doublets) > 2) {
      doublets = cbind(temp[tmp2$order, ], doublets[tmp2$order,
                                                    "TagIDs", drop = F])
    }
    else {
      doublets = cbind(temp, doublets[, "TagIDs", drop = F])
    }
    colnames(doublets) = c(colnames(temp), "TagIDs")
    doublets$TagIDs = as.character(doublets$TagIDs)
    doublets = as.data.frame(doublets)
  }
  file.name = sprintf("%s_demultiplex.txt", sample.name)
  file.name = paste(dir.name, file.name, sep = "")
  if (length(DP_index) > 0) {
    res1 = rbind(res1, doublets)
  }
  data.table::fwrite(res1, file.name, sep = "\t", quote = F,
                     row.names = T, col.names = T)
  cluster_annot = res1[, "TagIDs", drop = F]
  cluster_annot[, 1] = as.character(cluster_annot[, 1])
  colnames(cluster_annot) = "TagIDs"
  message("draw demultiplex heatmap...")
  cluster_palette = c("#a6cee3", "#1f78b4", "#b2df8a", "#33a02c",
                      "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6",
                      "#6a3d9a", "#ffff99", "#b15928", "#49beaa", "#611c35",
                      "#2708a0")
  cluster_colors = cluster_palette[1:length(unique(cluster_annot[,
                                                                 1]))]
  names(cluster_colors) = sort(unique(cluster_annot[, 1]))
  annotation_row = cluster_annot
  rownames(annotation_row) = rownames(res1)
  annotation_colors = list(TagIDs = cluster_colors)
  res1 = res1[order(res1$TagIDs, decreasing = F), ]
  bks = seq(scale.min - 0.1, scale.max + 0.1, by = 0.1)
  cols = grDevices::colorRampPalette(c("blue", "cyan", "white",
                                       "magenta", "red"))
  brcols = cols(length(bks))
  p = pheatmap::pheatmap(res1[, c(1:nTags)], scale = "none",
                         cluster_rows = FALSE, cluster_cols = FALSE, show_colnames = FALSE,
                         show_rownames = FALSE, annotation_row = annotation_row, border_color = NA,
                         annotation_colors = annotation_colors, annotation_names_row = FALSE,
                         color = brcols, breaks = bks, main = "log2 centered count")
  p = ggplotify::as.ggplot(p[[4]])
  if (is.null(prefix)) {
    file.name = sample.name
  }
  else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_demultiplex.png", file.name)
  file.name = paste(dir.name, file.name, sep = "")
  ggplot2::ggsave(file.name, p, device = "png", units = "in",
                  dpi = 300, width = 5, height = 6, limitsize = FALSE)
  grDevices::dev.off()
  message("add hashtag/sampletag/Abtag information to Seurat metadata...")
  if (object@version == "2.3.4") {
    raw.data = object@raw.data
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  }
  else if (object@version >= "3.0") {
    raw.data = GetAssayData(object, slot = "counts", assay = "RNA")
    if (nrow(raw.data) == 0) {
      stop(message("could not retrive raw count matrix from Seurat object. STOP"))
    }
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  }
  annot = as.character(res1[rownames(res1) %in% colnames(raw.data),
                            "TagIDs"])
  names(annot) = rownames(res1[rownames(res1) %in% colnames(raw.data),
  ])
  if (length(not_annotated_cell) > 0) {
    annot_NA = as.character(rep("not-detected", length(not_annotated_cell)))
    names(annot_NA) = setdiff(colnames(raw.data), rownames(data1))
    annot = c(annot, annot_NA)
  }
  if (is.null(prefix)) {
    slot.name = "TagIDs"
  }
  else {
    slot.name = paste("TagIDs", "-", prefix, sep = "")
  }
  object = AddMetaData(object = object, metadata = annot,
                       col.name = slot.name)
  for (i in c(1:nTags)) {
    hashtag_name = colnames(data0)[i]
    hashtag_name = paste(hashtag_name, ".log2", sep = "")
    annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),
                             i])
    annot = log2(annot + 1)
    names(annot) = rownames(data0[rownames(data0) %in% colnames(raw.data),
    ])
    if (length(not_annotated_cell) > 0) {
      annot_NA = rep(0, length(not_annotated_cell))
      names(annot_NA) = not_annotated_cell
      annot = c(annot, annot_NA)
    }
    object = Seurat::AddMetaData(object = object, metadata = annot,
                                 col.name = hashtag_name)
  }
  data0$first_most_probable = unlist(apply(data0[, c(1:nTags)],
                                           1, FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data0$second_most_probable = unlist(apply(data0[, c(1:nTags)],
                                            1, FUN = function(x) sort(x, decreasing = TRUE)[2]))
  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),
                           "first_most_probable"])
  names(annot) = rownames(data0[rownames(data0) %in% colnames(raw.data),
  ])
  if (length(not_annotated_cell) > 0) {
    annot_NA = rep(0, length(not_annotated_cell))
    names(annot_NA) = not_annotated_cell
    annot = c(annot, annot_NA)
  }
  if (is.null(prefix)) {
    slot.name = "first_most_probable_TagReads"
  }
  else {
    slot.name = paste("first_most_probable_TagReads", "-",
                      prefix, sep = "")
  }
  object = Seurat::AddMetaData(object = object, metadata = annot,
                               col.name = slot.name)
  annot = as.character(data0[rownames(data0) %in% colnames(raw.data),
                             "second_most_probable"])
  names(annot) = rownames(data0[rownames(data0) %in% colnames(raw.data),
  ])
  if (length(not_annotated_cell) > 0) {
    annot_NA = rep(0, length(not_annotated_cell))
    names(annot_NA) = not_annotated_cell
    annot = c(annot, annot_NA)
  }
  if (is.null(prefix)) {
    slot.name = "second_most_probable_TagReads"
  }
  else {
    slot.name = paste("second_most_probable_TagReads", "-",
                      prefix, sep = "")
  }
  object = Seurat::AddMetaData(object = object, metadata = annot,
                               col.name = slot.name)
  res = list()
  res[[1]] = object
  res[[2]] = p
  res[[3]] = p_doublet
  res[[4]] = round(min.fc, digits = 5)
  res[[5]] = length(p_list)
  return(res)
}
