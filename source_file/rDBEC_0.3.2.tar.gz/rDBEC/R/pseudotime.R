#' pseudotime_DEtest
#'
#' Perform monocle2 DE analysis against used-defined pseudotime lineages, based on VGAM package.
#'
#' @param object A Seurat object
#' @param pseudotime A data frame of pseuodtime lineage data of each cell. rownames are cell IDs and column IDs are lineage number.delimiter of count data table
#' @param lowerDetectionLimit the minimum expression level that consistitutes true expression
#' @param min_expr the expression threshold
#' @param min.pct the minimum cell numbers that each gene express
#' @param qvalue the upper threshold of qvalue
#' @param threads the number of threads for DE test
#'
#' @importFrom monocle newCellDataSet differentialGeneTest detectGenes
#' @importFrom foreach %dopar%
#' @rdname pseudotime_DEtest
#' @return A list of data frame of DE gene table for each pseudotime lineage
#' @export
#'

pseudotime_DEtest = function(object,
                             pseudotime,
                             lowerDetectionLimit=0.5,
                             min_expr = 5,
                             min.pct=0.05,
                             qvalue=0.05,
                             threads=8){
  # Prepare tables for monocle object
  print("Prepare for DE...")
  sig_genes_pseudoT=list()

  for (i in c(1:ncol(pseudotime))){

    lineage = pseudotime[!is.na(pseudotime[,i]),i]

    if (object@version == "2.3.4"){
    raw_data = object@raw.data[,colnames(object@raw.data) %in% names(lineage)]
    } else if (object@version >= "3.0"){
    raw_data = object@assays$RNA@counts[,colnames(object@assays$RNA@counts) %in% names(lineage)]
    }

    raw_data = as.matrix(raw_data)
    nf = 1000000/Matrix::colSums(raw_data)
    raw_data = sweep(raw_data, 2, nf, "*")

    if (object@version == "2.3.4"){
    sample_sheet <- data.frame(cells=colnames(raw_data), cellType=object@ident[colnames(raw_data)])
    } else if (object@version >= "3.0"){
    sample_sheet <- data.frame(cells=colnames(raw_data), cellType=object@active.ident[colnames(raw_data)])
    }

    rownames(sample_sheet)<- colnames(raw_data)
    gene_annotation <- data.frame(rownames(raw_data))
    rownames(gene_annotation)<- rownames(raw_data)
    colnames(gene_annotation)<- "gene_short_name"
    pd <- methods::new("AnnotatedDataFrame", data = sample_sheet)
    fd <- methods::new("AnnotatedDataFrame", data = gene_annotation)

    # Create a CellDataSet from the relative expression levels
    genes_pseudoT <- monocle::newCellDataSet(
      methods::as(raw_data, "sparseMatrix"),
      phenoData = pd,
      featureData = fd,
      lowerDetectionLimit=lowerDetectionLimit,
      expressionFamily=VGAM::negbinomial.size()
    )
    genes_pseudoT <- monocle::detectGenes(genes_pseudoT, min_expr = min_expr)
    genes_pseudoT <- genes_pseudoT[Biobase::fData(genes_pseudoT)$num_cells_expressed > length(lineage)*min.pct, ]
    genes_pseudoT <- BiocGenerics::estimateSizeFactors(genes_pseudoT)
    genes_pseudoT <- BiocGenerics::estimateDispersions(genes_pseudoT)

    lineage <- pseudotime[!is.na(pseudotime[,i]),i]
    genes_pseudoT$Pseudotime <- lineage

    print("Compute DE genes of lineage...")

    DE_genes_pseudoT <- monocle::differentialGeneTest(
      genes_pseudoT,
      fullModelFormulaStr="~sm.ns(Pseudotime, df=3)",
      cores = threads
    )
    DE_genes_pseudoT = DE_genes_pseudoT[DE_genes_pseudoT$qval<qvalue,]
    print("Done.")
    sig_genes_pseudoT[[i]]=DE_genes_pseudoT
  }
  return(sig_genes_pseudoT)
}

#' pseudotime_fitGAM
#'
#' Perform fitting GAM mode based on tradeSeq package.
#'
#' @param object A Seurat object
#' @param lineages A slingshot object
#' @param lowerDetectionLimit the minimum expression level that consistitutes true expression. default=0.5
#' @param min_expr the expression threshold. default=5
#' @param min.pct the minimum cell numbers that each gene express. default=0.05
#' @param knots the range of knot number during lineages for AIC testing. default=3:15
#' @param threadsAIC the number of threads for AIC test default=13
#' @param threadsGAM the number of threads for fitting GAM model. default=4
#' @param pct.eval.AIC percentage of genes use for AIC calculation. default=0.10
#' @param nknots specify pre-defined nknots value when you already evaluate nknots by AIC. default=NULL.
#' @param sample.name output plot name prefix.
#'
#' @importFrom tradeSeq fitGAM evaluateK
#' @importFrom stats lm
#' @importFrom foreach %dopar%
#'
#' @rdname pseudotime_fitGAM
#' @return A list of number of Knots and singlecellexperiment object for tradeseq downstream analysis
#' @export
#'

pseudotime_fitGAM = function(object,
                             lineages,
                             lowerDetectionLimit=0.5,
                             min_expr = 5,
                             min.pct=0.05,
                             threadsAIC=13,
                             knots=3:15,
                             pct.eval.AIC=0.10,
                             nknots=NULL,
                             sample.name="./Pseudotime",
                             threadsGAM=4){
  if (object@version == "2.3.4"){
  raw_data = object@raw.data
  } else if (object@version >= "3.0"){
  raw_data = object@assays$RNA@counts
  }

  if (object@version == "2.3.4"){
  raw_data = raw_data[,colnames(raw_data) %in% names(object@ident)]
  } else if (object@version >= "3.0"){
  raw_data = raw_data[,colnames(raw_data) %in% names(object@active.ident)]
  }

  raw_data = as.data.frame(as.matrix(raw_data))
  nf = 1000000/Matrix::colSums(raw_data)
  raw_data = sweep(raw_data, 2, nf, "*")
  raw_data = raw_data[rowSums(raw_data)>0,]

  if (object@version == "2.3.4"){
  sample_sheet = data.frame(cells=colnames(raw_data),
                            cellType=object@ident)
  } else if (object@version >= "3.0"){
    sample_sheet = data.frame(cells=colnames(raw_data),
                              cellType=object@active.ident)
    }

  rownames(sample_sheet) <- names(raw_data)
  gene_annotation <- as.data.frame(rownames(raw_data))
  rownames(gene_annotation )<- rownames(raw_data)
  colnames(gene_annotation) <- "gene_short_name"
  pd <- methods::new("AnnotatedDataFrame", data = sample_sheet)
  fd <- methods::new("AnnotatedDataFrame", data = gene_annotation)

  # Create a CellDataSet from the relative expression levels
  genes_pseudoT <- monocle::newCellDataSet(
    methods::as(as.matrix(raw_data), "sparseMatrix"),
    phenoData = pd,
    featureData = fd,
    lowerDetectionLimit=lowerDetectionLimit,
    expressionFamily=VGAM::negbinomial.size()
  )
  genes_pseudoT <- monocle::detectGenes(genes_pseudoT, min_expr = min_expr)
  genes_pseudoT <- BiocGenerics::estimateSizeFactors(genes_pseudoT)
  genes_pseudoT <- genes_pseudoT[Biobase::fData(genes_pseudoT)$num_cells_expressed > ncol(raw_data)*min.pct, ]
  raw_data = Biobase::exprs(genes_pseudoT)
  raw_data = raw_data/Biobase::pData(genes_pseudoT)[, 'Size_Factor']

  if(is.null(nknots)){
  icMat = tradeSeq::evaluateK(counts = raw_data, sds = lineages, k = knots,
                    nGenes = round(nrow(raw_data)*pct.eval.AIC, 0),
                    verbose = FALSE, plot = FALSE, ncores=threadsAIC)

  gc()

  #detect elbow polint of AIC plot.
  #see https://stackoverflow.com/questions/2018178/finding-the-best-trade-off-point-on-a-curve
  elbow_finder <- function(x_values, y_values) {
    # Max values to create line
    max_x_x <- max(x_values)
    max_x_y <- y_values[which.max(x_values)]
    max_y_y <- max(y_values)
    max_y_x <- x_values[which.max(y_values)]
    max_df <- data.frame(x = c(max_y_x, max_x_x), y = c(max_y_y, max_x_y))

    # Creating straight line between the max values
    fit <- stats::lm(max_df$y ~ max_df$x)

    # Distance from point to line
    distances <- c()
    for(i in 1:length(x_values)) {
      distances <- c(distances, abs(stats::coef(fit)[2]*x_values[i] - y_values[i] + stats::coef(fit)[1]) / sqrt(stats::coef(fit)[2]^2 + 1^2))
    }

    # Max distance point
    x_max_dist <- x_values[which.max(distances)]
    y_max_dist <- y_values[which.max(distances)]

    return(c(x_max_dist, y_max_dist))
  }

  #remove AIC values more than the first three knots for optimal detection of elbow point
  tmp = colMeans(icMat, na.rm = TRUE)
  tmp = tmp[tmp<=min(tmp[1],tmp[2], tmp[3])]
  AIC.elbow =elbow_finder(c(1:length(tmp)), tmp)
  file.name=paste(sample.name, "AIC.png", sep='_')
  grDevices::png(file.name, width = 600, height = 300)
  graphics::par(mfrow = c(1, 2))

  #boxplot
  devs <- matrix(NA, nrow = nrow(icMat), ncol = length(tmp))
  for (ii in seq_len(length(tmp))) {
    devs[ii, ] <- icMat[ii, c(1:length(tmp))] - mean(icMat[ii, c(1:length(tmp))])
  }
  graphics::boxplot(devs, ylab = "Deviation from genewise average AIC",
          xlab = "Number of knots", xaxt = "n")
  graphics::axis(1, at = seq_len(length(tmp)), labels = knots[1:length(tmp)])
  #elbow plot
  graphics::plot(x = knots[1:length(tmp)], y = colMeans(icMat, na.rm = TRUE)[1:length(tmp)], type = "b",
       ylab = "Average AIC", xlab = "Number of knots")
  graphics::abline(v = as.integer(AIC.elbow[1]), col=c("magenta"), lwd=1)
  grDevices::dev.off()
  nknots = as.integer(AIC.elbow[1])
  }
  #fit GAM model
  pseudotime = slingshot::slingPseudotime(lineages, na = FALSE)
  pseudotime = pseudotime[rownames(pseudotime) %in% colnames(raw_data),]
  cellWeights = slingshot::slingCurveWeights(lineages)
  cellWeights = cellWeights[rownames(cellWeights) %in% colnames(raw_data),]

  sce = tradeSeq::fitGAM(counts = raw_data,
                         pseudotime=pseudotime,
                         cellWeights=cellWeights,
               nknots = nknots, verbose = TRUE, parallel=TRUE,
               threads=threadsGAM)
  res = list()
  res[[1]]=nknots
  res[[2]]=sce
  names(res[[1]])="nknots_AICoptim"
  return(res)
}


#' pseudotime_DE2
#'
#' Perform DE analysis based on tradeSeq package.
#'
#' @param sce A singlecellexperiment object from tradeseq output
#' @param object A Seurat object
#' @param lineages A slingshot object
#' @param minFC A threshold of fold-change
#' @param adj.pval A threshold of adjusted p value
#' @param p.adjust.method A method for multiple test. defaault="BH"
#' @param nknots A total knot number for sliding window DE test.
#' @param pairwise logical. Specify pairwise comparisons between lineages
#' @param lowerDetectionLimit the minimum expression level that consistitutes true expression
#' @param min_expr the expression threshold
#' @param min.pct the minimum cell numbers that each gene express
#' @param threads the number of threads for DE test for monocle2_VGAM
#'
#' @importFrom tradeSeq associationTest startVsEndTest diffEndTest earlyDETest patternTest
#' @importFrom stats p.adjust
#' @importFrom foreach %dopar%
#'
#' @rdname pseudotime_DE2
#' @return A data.frame of p.value and log2FC for each gene
#' @export
#'

pseudotime_DE2 = function(sce,
                          object,
                          lineages,
                          minFC=1.5,
                          adj.pval=0.05,
                          p.adjust.method="BH",
                          nknots=NULL,
                          pairwise=TRUE,
                          lowerDetectionLimit=0.5,
                          min_expr = 5,
                          min.pct=0.05,
                          threads=8
                          ){
  if(is.null(nknots)){
  stop("please provide number of Knots for fiting GAM model")
  }
  DE_res=list()

  #perform DE analysis along lineages
  message("Compute lineage-associated DE genes by monocle2 and VGAM pipeline...")
  sig_genes_pseudoT=list()
  pseudotime = slingshot::slingPseudotime(lineages)
  for (i in c(1:ncol(pseudotime))){

    lineage = pseudotime[!is.na(pseudotime[,i]),i]

    if (object@version == "2.3.4"){
    raw_data = object@raw.data[,colnames(object@raw.data) %in% names(lineage)]
    } else if (object@version >= "3.0"){
    raw_data = object@assays$RNA@counts[,colnames(object@assays$RNA@counts) %in% names(lineage)]
    }

    raw_data = as.matrix(raw_data)
    nf = 1000000/Matrix::colSums(raw_data)
    raw_data = sweep(raw_data, 2, nf, "*")

    if (object@version == "2.3.4"){
    sample_sheet <- data.frame(cells=colnames(raw_data), cellType=object@ident[colnames(raw_data)])
    } else if (object@version >= "3.0"){
    sample_sheet <- data.frame(cells=colnames(raw_data), cellType=object@active.ident[colnames(raw_data)])
    }

    rownames(sample_sheet)<- colnames(raw_data)
    gene_annotation <- data.frame(rownames(raw_data))
    rownames(gene_annotation)<- rownames(raw_data)
    colnames(gene_annotation)<- "gene_short_name"
    pd <- methods::new("AnnotatedDataFrame", data = sample_sheet)
    fd <- methods::new("AnnotatedDataFrame", data = gene_annotation)

    # Create a CellDataSet from the relative expression levels
    genes_pseudoT <- monocle::newCellDataSet(
      methods::as(raw_data, "sparseMatrix"),
      phenoData = pd,
      featureData = fd,
      lowerDetectionLimit=lowerDetectionLimit,
      expressionFamily=VGAM::negbinomial.size()
    )
    genes_pseudoT <- monocle::detectGenes(genes_pseudoT, min_expr = min_expr)
    genes_pseudoT <- genes_pseudoT[Biobase::fData(genes_pseudoT)$num_cells_expressed > length(lineage)*min.pct, ]
    genes_pseudoT <- BiocGenerics::estimateSizeFactors(genes_pseudoT)
    genes_pseudoT <- BiocGenerics::estimateDispersions(genes_pseudoT)

    lineage <- pseudotime[!is.na(pseudotime[,i]),i]
    genes_pseudoT$Pseudotime <- lineage

    suppressWarnings(DE_genes_pseudoT <- monocle::differentialGeneTest(
      genes_pseudoT,
      fullModelFormulaStr="~sm.ns(Pseudotime, df=3)",
      cores = threads
    ))

    gc()
    hoge = Biobase::exprs(genes_pseudoT)/Biobase::pData(genes_pseudoT)[, 'Size_Factor']
    row_max = qlcMatrix::rowMax(hoge, ignore.zero=TRUE)
    row_max = log2(row_max+1)
    row_min = qlcMatrix::rowMin(hoge, ignore.zero=TRUE)
    row_min = log2(row_min+1)
    row_FC = row_max - row_min
    names(row_FC)=rownames(hoge)
    DE_genes_pseudoT = DE_genes_pseudoT[,c(5,3)] #only extract gene name and pvalue
    colnames(DE_genes_pseudoT)[2]="pvalue"
    DE_genes_pseudoT = cbind(DE_genes_pseudoT, logFC=row_FC)
    colnames(DE_genes_pseudoT)[2:3]=paste(colnames(DE_genes_pseudoT)[2:3], i ,sep="_")
    sig_genes_pseudoT[[i]]=DE_genes_pseudoT
  }

  DE_combine1=sig_genes_pseudoT[[1]]
  if(length(sig_genes_pseudoT)>1){
   for (i in c(2:length(sig_genes_pseudoT))){
    DE_combine1 = dplyr::full_join(DE_combine1,
                                   sig_genes_pseudoT[[i]],
                                   by="gene_short_name")
    rownames(DE_combine1) = DE_combine1[,1]
   }
  }
  DE_res[[1]] = DE_combine1[,2:ncol(DE_combine1)]

  #perform DE analysis among knots
  message("perform DE analyses among lineages by tradeSeq pipeline...")
  DE_res[[2]] = tradeSeq::startVsEndTest(sce, l2fc = log2(minFC))

  #we can perform between-lineage comparisons when more than 1 lineages exist
  if (length(sce$slingshot)>2){
   DE_res[[3]] = tradeSeq::patternTest(sce, l2fc = log2(minFC))
   DE_res[[4]] = tradeSeq::diffEndTest(sce, l2fc = log2(minFC),pairwise=pairwise)

    if (nknots > 2){
    for (i in c(1:(nknots-2))){
    DE_res[[i+4]] = tradeSeq::earlyDETest(sce, knots = c(i, i+1), l2fc = log2(minFC),pairwise=pairwise)
    }
    }
  }

  message("conbine DE test results and adjust p values...")
  DE_res = lapply(DE_res, na.omit)

  DE_combine=DE_res[[1]]
  for (i in c(2:length(DE_res))){
    DE_combine = dplyr::full_join(tibble::rownames_to_column(DE_combine),
                                  tibble::rownames_to_column(DE_res[[i]]),
                                  by="rowname")
    rownames(DE_combine) = DE_combine[,1]
    DE_combine = DE_combine[,2:ncol(DE_combine)]
  }

  pvalue = grep(pattern = "pvalue", x = colnames(DE_combine), value = FALSE)
  pvalue = DE_combine[,pvalue]
  pvalue[is.na(pvalue)] = 1
  pvalue$adj_min_pvalue = stats::p.adjust(Biobase::rowMin(as.matrix(pvalue)), method=p.adjust.method)

  log2FC_1 = grep(pattern = "[lL]ogFC", x = colnames(DE_combine), value = FALSE)
  log2FC_2 = grep(pattern = "fcmedian", x = colnames(DE_combine), value = FALSE)
  log2FC = unique(c(log2FC_1, log2FC_2))
  log2FC = DE_combine[,log2FC]
  log2FC = abs(log2FC)
  log2FC[is.na(log2FC)] = 0
  log2FC$max_abs_logFC = Biobase::rowMax(as.matrix(log2FC))

  DE_res = cbind(adj_min_pvalue=pvalue$adj_min_pvalue, max_abs_logFC=log2FC$max_abs_logFC)
  rownames(DE_res) = rownames(DE_combine)
  DE_res = as.data.frame(DE_res)
  DE_res = DE_res[DE_res$max_abs_logFC>=log2(minFC),]
  DE_res = DE_res[DE_res$adj_min_pvalue<=adj.pval,]
  message(paste(nrow(DE_res), "DE genes found.", sep=" "))
  return(DE_res)
}



#' mean_smoothened
#'
#' internal function of calculate means of smoothened counts of starting point cells
#'
#' @param data1 A list of smoothened expression matrix of each pseudotime lineages
#' @param j A column number
#'
#'
#' @rdname mean_smoothened
#' @return A vector of mean value of smoothened expression count data
#' @export
#'

mean_smoothened =  function(data1, j){
  tmp = data1[[1]][,j, drop=F]
  if (length(data1)>1){
    for (k in c(2:length(data1))){
      tmp = dplyr::full_join(tibble::rownames_to_column(as.data.frame(tmp)),
                             tibble::rownames_to_column(as.data.frame(data1[[k]][,j, drop=F])),
                             by = "rowname")
      rownames(tmp)=tmp$rowname
      tmp = tmp[,2:ncol(tmp)]
    }}
  tmp1 = Matrix::rowMeans(tmp, na.rm=TRUE)
  tmp1 = data.frame(tmp1)
  rownames(tmp1)=rownames(tmp)
  colnames(tmp1)=colnames(data1[[1]])[j]
  names(tmp1)=colnames(data1[[1]])[j]
  return(tmp1)
}

utils::globalVariables(names = c("qval", "num_cells_expressed"),
                       package = 'rDBEC',
                       add = TRUE)
#' pseudotimeDE_clustering
#'
#' clustering and plotting DE genes by each pseudotime lineage.
#'
#' @param sig_gene_pseudoT A list of DE gene table
#' @param object A Seurat object
#' @param pseudotime A cell named vector of pseudotime value
#' @param lowerDetectionLimit A monocle lower ditectionlomit parameter.
#' @param min_expr A monocle min_expr parameter.
#' @param min.pct A minimum percent of expressed cells of each gene in each lineage
#' @param ident1 A cell identity of Seurat object, default is orig.ident
#' @param clustering.ident A cell cluster identity of Seurat object.
#' @param reduction.use A dimentional reduction method fro visulaization of Seurat object.
#' @param deepSplit A cutreeDymamic split parameter.
#' @param qvalue A qvalue threshold of DEGs
#' @param threads A paralell computing for smoothing.
#' @param WGCNAthreads A WGCNA threads parameter.
#' @param sft_max A upper limit of sft threshold calculaton of WGCNA analysis
#' @param sft_limit A upper limit of sft threshold of WGCNA analysis
#' @param merge_thres A parameter for merging WGCNA modules
#' @param scale_max A maximum scale value for heatmap drawing
#' @param scale_min A minimum scale value for heatmap drawing
#' @param sample.name A prefix file name for output files
#'
#' @import Seurat
#' @import WGCNA
#' @importFrom stats cutree as.dist sd
#' @importFrom foreach %dopar%
#'
#' @rdname pseudotimeDE_clustering
#' @return A data.frame of DEG clustering result and associated annotated heatmap
#' @export
#'
#'

pseudotimeDE_clustering <- function(sig_gene_pseudoT,
                                object,
                                pseudotime,
                                lowerDetectionLimit=0.5,
                                min_expr = 5,
                                min.pct=0.05,
                                ident1="orig.ident",
                                clustering.ident=object@ident,
                                reduction.use="optSNE",
                                deepSplit=4,
                                qvalue=0.001,
                                threads=8,
                                WGCNAthreads=24,
                                sft_max=25,
                                sft_limit=20,
                                merge_thres=0.25,
                                scale_max=2.5,
                                scale_min=-2.5,
                                sample.name="./Pseudotime"){

  lineage=list()
  sig_var_gene_pseudoT=list()
  smooth=list()
  lineage_name=list()
  orig_ident_annot=list()
  ident_annot=list()
  DE_gene_pseudoT=list()

  #filter DE gene list
  ncells_in_lineage = nrow(pseudotime[!is.na(pseudotime[,1]),])
  for (i in c(1:length(sig_gene_pseudoT))){
  DE_gene_pseudoT[[i]] = subset(sig_gene_pseudoT[[1]],
                                qval < qvalue & num_cells_expressed > ncells_in_lineage * min.pct)
  }

  ALL_siggenes= rownames(DE_gene_pseudoT[[1]])
  if(length(DE_gene_pseudoT)>1){
    for (i in c(2:length(DE_gene_pseudoT))){
      ALL_siggenes= c(ALL_siggenes, rownames(DE_gene_pseudoT[[i]]))
    }}
  ALL_siggenes = unique(ALL_siggenes)

  #extract common root cells
  start_cells = rownames(pseudotime[rowSums(is.na(pseudotime))==0,])

  #prepare SingleCellDataset object for smoothing
  if (object@version == "2.3.4"){
  raw_data = object@raw.data[,colnames(object@raw.data) %in% rownames(pseudotime)]
  } else if (object@version >= "3.0"){
  raw_data = object@assays$RNA@counts[,colnames(object@assays$RNA@counts) %in% rownames(pseudotime)]
  }

  raw_data = as.data.frame(as.matrix(raw_data))
  nf = 1000000/Matrix::colSums(raw_data)
  raw_data = sweep(raw_data, 2, nf, "*")
  raw_data = raw_data[rowSums(raw_data)>0,]
  sample_sheet = data.frame(cells=colnames(raw_data), cellType=clustering.ident[names(clustering.ident) %in% colnames(raw_data)])
  rownames(sample_sheet) <- names(raw_data)
  gene_annotation <- as.data.frame(rownames(raw_data))
  rownames(gene_annotation )<- rownames(raw_data)
  colnames(gene_annotation) <- "gene_short_name"
  pd <- methods::new("AnnotatedDataFrame", data = sample_sheet)
  fd <- methods::new("AnnotatedDataFrame", data = gene_annotation)

  # Create a CellDataSet from the relative expression levels
  genes_pseudoT <- monocle::newCellDataSet(
    methods::as(as.matrix(raw_data), "sparseMatrix"),
    phenoData = pd,
    featureData = fd,
    lowerDetectionLimit=lowerDetectionLimit,
    expressionFamily=VGAM::negbinomial.size()
  )
  genes_pseudoT <- monocle::detectGenes(genes_pseudoT, min_expr = min_expr)
  genes_pseudoT <- genes_pseudoT[Biobase::fData(genes_pseudoT)$num_cells_expressed > 10, ]
  genes_pseudoT <- BiocGenerics::estimateSizeFactors(genes_pseudoT)

  for (i in c(1:ncol(pseudotime))){
    lineage[[i]] <- pseudotime[!is.na(pseudotime[,i]),i]

    genes_pseudoT1 <- genes_pseudoT[,colnames(genes_pseudoT) %in% names(lineage[[i]])]
    genes_pseudoT1$Pseudotime <- lineage[[i]]

    sig_var_gene_pseudoT[[i]] = genes_pseudoT1[rownames(DE_gene_pseudoT[[i]]),]

    print(paste(nrow(sig_var_gene_pseudoT[[i]]), " genes selected.", sep=""))

    if (nrow(sig_var_gene_pseudoT[[i]])>=10){
      #message("Smooth gene expression...")

      smooth[[i]] = Biobase::exprs(sig_var_gene_pseudoT[[i]])/Biobase::pData(sig_var_gene_pseudoT[[i]])[, 'Size_Factor']
      smooth[[i]]=as.data.frame(as.matrix(smooth[[i]]))

      tmp = genes_pseudoT[setdiff(Biobase::fData(genes_pseudoT)[,1],rownames(smooth[[i]])),colnames(smooth[[i]])]
      tmp = Biobase::exprs(tmp)/Biobase::pData(tmp)[, 'Size_Factor']
      tmp=as.data.frame(as.matrix(tmp))
      smooth[[i]] = rbind(smooth[[i]], tmp)
      smooth[[i]] = log10(smooth[[i]]+1)
      gc()

      message("Done.")

      message("Annotate cells...")
      #extract annotations of cells of each lineage

      #orig.ident annotation and colors
      orig.ident.annot = object@meta.data[,ident1]
      names(orig.ident.annot) = rownames(object@meta.data)
      orig.ident.annot = as.factor(orig.ident.annot)
      orig_ident_annot[[i]]=orig.ident.annot[names(orig.ident.annot) %in% colnames(smooth[[i]])]

      #cluster annotation
      ident.annot = clustering.ident
      ident_annot[[i]]=ident.annot[names(ident.annot) %in% colnames(smooth[[i]])]

      #normalize pseudotime (from 0 to 1)
      lineage[[i]] = lineage[[i]][names(lineage[[i]]) %in% colnames(smooth[[i]])]
      smooth[[i]]=smooth[[i]][ , order(lineage[[i]])]
      lineage[[i]] = (lineage[[i]]-min(lineage[[i]]))/(max(lineage[[i]])-min(lineage[[i]]))

      #rename cells by lineage
      names(ident_annot[[i]])=paste(i, names(ident_annot[[i]]), sep="_")
      names(orig_ident_annot[[i]])=paste(i, names(orig_ident_annot[[i]]), sep="_")
      colnames(smooth[[i]])=paste(i, colnames(smooth[[i]]), sep="_")
      names(lineage[[i]])=paste(i, names(lineage[[i]]), sep="_")

      #lineage number annotation
      lineage_name[[i]]=as.character(rep(i, length(smooth[[i]])))
      names(lineage_name[[i]])=names(smooth[[i]])
      names(lineage_name[[i]])=paste(i, names(lineage_name[[i]]), sep="_")
    } else {
      message(paste("lineage", i, "has no significant DEGs", sep=" "))
    }
  }


  message("Build cell annotations...")
  # Color palette for the heatmap
  cold = grDevices::colorRampPalette(c('#f7fcf0','#41b6c4','#253494','#081d58', '#081d58'))
  warm = grDevices::colorRampPalette(c('#ffffb2','#fecc5c','#e31a1c','#800026'))
  mypalette = c(rev(cold(20)), warm(21))
  breaksList = seq(-10, 10, by = 0.5)

  #specify orig.ident colors
  if (object@version == "2.3.4"){
  p1 = Seurat::DimPlot(object = object, reduction.use = reduction.use, group.by = ident1,
               do.return = TRUE, vector.friendly = FALSE, pt.size = 0.3, no.legend=FALSE)
  } else if (object@version >= "3.0"){
  p1 = Seurat::DimPlot(object = object, reduction = reduction.use, group.by = ident1,combine=FALSE,
                         pt.size = 0.3)
  }


  orig_ident_build = ggplot2::ggplot_build(p1)
  orig_ident_build = orig_ident_build$data[[1]]
  orig_ident_build =  orig_ident_build[order(orig_ident_build$group), ]
  orig.ident.cols = unique(orig_ident_build$colour) # Get a vector of unique colors
  names(orig.ident.cols)=sort(as.character(unique(object@meta.data[,ident1])))

  #specify cluster colors
  if (object@version == "2.3.4"){
  p2 = Seurat::DimPlot(object = object, reduction.use = reduction.use,
               do.return = TRUE, vector.friendly = FALSE, pt.size = 0.3, no.legend=FALSE)
  } else if (object@version >= "3.0"){
  p2 = Seurat::DimPlot(object = object, reduction = reduction.use, combine=FALSE,
                         pt.size = 0.3)
  }
  ident_build = ggplot2::ggplot_build(p2)
  ident_build = ident_build$data[[1]]
  ident_name = ident_build$group
  ident_name = ident_name-1
  names(ident_name)=rownames(object@meta.data)
  ident_name=as.factor(ident_name)
  levels(ident_name)=levels(clustering.ident)
  ident.cols = unique(ident_build[,c(2,6)])
  ident.cols = ident.cols[order(ident.cols$group),]
  ident.cols = ident.cols[,1]
  names(ident.cols) = c(0:(length(ident.cols)-1))
  ident.cols=as.factor(ident.cols)
  levels(ident.cols)=levels(clustering.ident)

  #specify lineage colors
  lineage_name_colors = scales::hue_pal()(ncol(pseudotime))
  names(lineage_name_colors) = as.character(c(1:ncol(pseudotime)))

  #specify pseudotime colors
  lineage_colors = warm(21)

  #merge cell annotations
  lineage_name=unlist(lineage_name)
  orig_ident_annot=unlist(orig_ident_annot)
  ident_annot=unlist(ident_annot)
  lineage=unlist(lineage)

  message("Merge each lineages and Cluster the genes by WGCNA pipeline...")

  #combine and scale expression matrix
  smooth_combine=smooth[[1]]
  if(length(smooth)>1){
    for (i in c(2:length(smooth))){
      smooth_combine = dplyr::full_join(tibble::rownames_to_column(as.data.frame(smooth_combine)),
                                       tibble::rownames_to_column(as.data.frame(smooth[[i]])),
                                       by = "rowname")
      rownames(smooth_combine)=smooth_combine$rowname
      smooth_combine = smooth_combine[,2:ncol(smooth_combine)]
    }
  }
  smooth_combine[is.na(smooth_combine)] = 0
  smooth_combine=smooth_combine[rownames(smooth_combine) %in% ALL_siggenes,]
  smooth_combine=t(smooth_combine)

  #pick soft threshold
  quiet <- function(x) {
    sink(tempfile())
    on.exit(sink())
    invisible(force(x))
  }

  quiet(WGCNA::allowWGCNAThreads(WGCNAthreads))
  powerseq=c(seq(1,25,by=1))
  sft=quiet(WGCNA::pickSoftThreshold(smooth_combine, powerVector=powerseq, verbose=0))
  thre=data.frame(power=sft$fitIndices[,1], fit=-sign(sft$fitIndices[,3])*sft$fitIndices[,2])
  thre[,2]=thre[,2]-min(thre[,2])
  thre[,2]=abs(thre[,2]-max(thre[,2]))

  elbow_finder <- function(x_values, y_values) {
    # Max values to create line
    max_x_x <- max(x_values)
    max_x_y <- y_values[which.max(x_values)]
    max_y_y <- max(y_values)
    max_y_x <- x_values[which.max(y_values)]
    max_df <- data.frame(x = c(max_y_x, max_x_x), y = c(max_y_y, max_x_y))

    # Creating straight line between the max values
    fit <- stats::lm(max_df$y ~ max_df$x)

    # Distance from point to line
    distances <- c()
    for(i in 1:length(x_values)) {
      distances <- c(distances,
                     abs(stats::coef(fit)[2]*x_values[i] - y_values[i] + stats::coef(fit)[1]) / sqrt(stats::coef(fit)[2]^2 + 1^2))
    }

    # Max distance point
    x_max_dist <- x_values[which.max(distances)]
    y_max_dist <- y_values[which.max(distances)]

    return(c(x_max_dist, y_max_dist))
  }

  thre1 = elbow_finder(thre[,1], thre[,2])

  pw1=thre1[1]

  if (pw1>=sft_limit){
    message(paste("Auto-detect soft threshold is ", pw1,
                  " ,exceeds user-supplied limit. use user-supplied value", sep=""))
    pw1 = sft_limit
  }

  file.name=paste(sample.name, "softThreshold.png", sep='_')
  grDevices::png(file.name, width = 600, height = 400)
  graphics::par(mfrow=c(1,2))
  cex1=0.9;
  plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       xlab="Soft Threshold (power)", ylab="Scale Free Topology Model Fit, signed R^2", type="n",
       main=paste("Scale independence"))
  graphics::text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       labels=powerseq, cex=cex1,col="red")
  graphics::abline(h=0.90, col="red")
  graphics::abline(v=pw1, col="cyan")
  graphics::plot(sft$fitIndices[,1],sft$fitIndices[,5],
       xlab="Soft Threshold (power)", ylab="Mean Connectivity", type="n",
       main=paste("Mean connectivity"))
  graphics::text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powerseq, cex=cex1, col="red")
  grDevices::dev.off()

  #calculate topological overlap matrix
  adj1=quiet(WGCNA::adjacency(smooth_combine,power=pw1))
  convec=quiet(WGCNA::softConnectivity(smooth_combine,
                          corFnc = "cor", corOptions = "use = 'p'",type = "unsigned",
                          power =pw1,blockSize = 1500,
                          minNSamples = NULL,verbose = 2, indent = 0))
  stom1=WGCNA::TOMsimilarity(adj1)
  dissim=1-stom1

  # clustering
  genetree=flashClust::flashClust(as.dist(dissim), method="average")

  # detection of modules
  merge_thres=merge_thres      # often 0.25
  dmd1=dynamicTreeCut::cutreeDynamic(dendro=genetree, distM=dissim,
                     deepSplit=deepSplit)
  dc1=WGCNA::labels2colors(dmd1)

  #   merging of initial modules
  melist=WGCNA::moduleEigengenes(smooth_combine, colors=dc1)
  mes=melist$eigengenes
  mediss=1-WGCNA::cor(mes)
  metree=flashClust::flashClust(as.dist(mediss), method="average")
  merge=WGCNA::mergeCloseModules(smooth_combine,dc1,cutHeight=merge_thres,
                          relabel=TRUE, verbose=3)
  colorOrder=c("grey", standardColors(50))
  #modcol=merge$colors
  modcol=data.frame(original=dc1, merge=merge$colors)
  modlab=match(modcol, colorOrder)-1
  modme=merge$newMEs
  file.name=paste(sample.name, "Dendrogram.png", sep='_')
  grDevices::png(file.name, width = 600, height = 400)
  graphics::par(mfrow=c(1,1))
  WGCNA::plotDendroAndColors(genetree,modcol, c("original", "merged"),
                      dendroLabels=FALSE, hang=0.03,addGuide=TRUE, guideHang=0.05,
                      main="Gene dendrogram and module colors")
  grDevices::dev.off()

  # heatmap of eigengene
  me1=WGCNA::moduleEigengenes(smooth_combine,merge$colors)$eigengenes
  meord=WGCNA::orderMEs(me1)

  file.name=paste(sample.name, "Dendrogram_Eigengenes.png", sep='_')
  grDevices::png(file.name, width = 400, height = 600)
  graphics::par(mfrow=c(1,2))
  WGCNA::plotEigengeneNetworks(meord, "Eigengene dendrogram",
                        marDendro=c(0,4,2,2), marHeatmap=c(3,4,2,2))
  grDevices::dev.off()

  #draw Eigengene heatmap by pseudotime
  message("Draw eigengene pseudotime heatmap...")
  temp = t(meord)
  temp = temp[c(1:nrow(temp)-1),]

  annotation_col = data.frame(
    Pseudotime=lineage,
    Seurat_Clusters=ident_annot,
    orig.ident=orig_ident_annot,
    lineageNb=lineage_name
  )

  Eigengenes = rownames(temp)
  names(Eigengenes) = rownames(temp)

  annotation_row = data.frame(Eigengenes=Eigengenes)
  rownames(annotation_row)=rownames(temp)

  Eigen_colors=gsub("ME", "", rownames(temp))
  names(Eigen_colors)=rownames(temp)

  annotation_colors = list(
    Pseudotime=lineage_colors,
    lineageNb=lineage_name_colors,
    Seurat_Clusters=ident.cols,
    orig.ident=orig.ident.cols,
    Eigengenes=Eigen_colors
  )
  gaps_col2=NULL
  if(length(unique(annotation_col$lineageNb))>1){
  gaps_col = utils::head(as.numeric(cumsum(table(as.numeric(annotation_col$lineageNb)))), -1)
  root_cells = nrow(pseudotime[Matrix::rowSums(is.na(pseudotime))==0,])
  gaps_col1 = gaps_col + root_cells
  gaps_col2 = root_cells
   for (i in c(1:length(gaps_col))){
    gaps_col2=c(gaps_col2, gaps_col[i])
    gaps_col2=c(gaps_col2, gaps_col1[i])
   }
  }

  temp=temp[!apply(temp,1,sd)==0,]
  temp=Matrix::t(scale(Matrix::t(temp),center=TRUE))
  temp=temp[is.na(rownames(temp)) == FALSE,]
  temp[is.nan(temp)] = 0
  temp[temp>scale_max] = scale_max
  temp[temp<scale_min] = scale_min
  bks = seq(scale_min-0.1, scale_max+0.1, by = 0.1)
  hmcols = viridis::inferno(length(bks))

  if(length(unique(annotation_col$lineageNb))>1){
  p = pheatmap::pheatmap(
    as.data.frame(temp),
    scale="none",
    cluster_cols=FALSE,
    cluster_rows=FALSE,
    show_colnames=FALSE,
    show_rownames=TRUE,
    annotation_col=annotation_col,
    annotation_row=annotation_row,
    annotation_colors=annotation_colors,
    annotation_names_row = FALSE,
    gaps_col = gaps_col2,
    gaps_row = utils::head(as.numeric(cumsum(table(1:length(annotation_row$Eigengenes)))), -1),
    color=hmcols,
    breaks = bks,
    silent=TRUE,
    main="pseudotime_Eigengenes"
  )
  } else {
    p = pheatmap::pheatmap(
      as.data.frame(temp),
      scale="none",
      cluster_cols=FALSE,
      cluster_rows=FALSE,
      show_colnames=FALSE,
      show_rownames=TRUE,
      annotation_col=annotation_col,
      annotation_row=annotation_row,
      annotation_colors=annotation_colors,
      annotation_names_row = FALSE,
      gaps_row = utils::head(as.numeric(cumsum(table(1:length(annotation_row$Eigengenes)))), -1),
      color=hmcols,
      breaks = bks,
      silent=TRUE,
      main="pseudotime_Eigengenes")
  }
  p_annotlegend = gtable::gtable_filter(p$gtable, pattern="annotation_legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p$gtable, pattern="legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p_heatlegend, pattern="annotation_legend", fixed=TRUE, invert=TRUE)
  p_main = gtable::gtable_filter(p$gtable, pattern="legend", invert=TRUE)

  file.name=paste(sample.name, "Eigengenes_pseudotime.png", sep='_')
  cowplot::save_plot(file = file.name,
                     cowplot::plot_grid(p_main, p_heatlegend, p_annotlegend,
                                        ncol=3, nrow=1, rel_widths = c(1, .06, .1), scale=1),
                     device="png",
                     units="in", dpi = 300, base_width = 14,
                     base_height = 10, limitsize=FALSE)

  #sub-clusterings within WGCNA modules and draw heatmap
  colcondf=data.frame(Symbol=colnames(smooth_combine), Color=modcol[,2])
  rownames(colcondf)=as.character(colcondf[,1])
  gene_clusters=list()
  genes_ordering=list()
  silhouette=list()
  scaled_data=NULL

  for (i in c(1:length(Eigen_colors))){
    tmp_genes=NULL
    for (j in c(1:length(smooth))){
      tmp2 = paste("^", j,"_", sep="")
      if (object@version == "2.3.4"){
      hoge = object@scale.data[rownames(colcondf[colcondf$Color == Eigen_colors[i],]),
                               gsub(tmp2, "", colnames(smooth[[j]]))]
      } else if (object@version >= "3.0"){
      hoge = object@assays$RNA@scale.data[rownames(colcondf[colcondf$Color == Eigen_colors[i],]),
                                 gsub(tmp2, "", colnames(smooth[[j]]))]
      }

      colnames(hoge)=colnames(smooth[[j]])
      tmp_genes=cbind(tmp_genes, hoge)
    }
    tmp_genes[tmp_genes>10] = 10
    tmp_genes[tmp_genes<-10] = -10

    MyhclustFUN = function(x,k){
      dist_matrix <- stats::as.dist((1 - WGCNA::cor(Matrix::t(x), method="pearson", nThreads=12))/2)
      dist_matrix[is.na(dist_matrix)] <- 1
      gene_clustering = flashClust::flashClust(dist_matrix, method="ward")
      return(list(cluster=stats::cutree(gene_clustering, k)))
    }
    quiet(WGCNA::allowWGCNAThreads(WGCNAthreads))
    silhouette[[i]] =  try(factoextra::fviz_nbclust(tmp_genes, MyhclustFUN,
                                    method="silhouette",
                                    k.max=2), silent=TRUE)

    #clustering
     dist_matrix <- stats::as.dist((1 - WGCNA::cor(Matrix::t(tmp_genes), method="pearson", nThreads=WGCNAthreads/2))/2)
     dist_matrix[is.na(dist_matrix)] <- 1
     gene_clustering = flashClust::flashClust(dist_matrix, method="ward")
    if (class(silhouette[[i]]) != "try-error" && class(silhouette[[i]]) != "NULL") {
     silhouette[[i]]
     hoge1 = silhouette[[i]][[1]][order(silhouette[[i]][[1]][,2], decreasing=T),]
     if(as.numeric(hoge1[1,1])>1){
     clusters = stats::cutree(gene_clustering,
                      k = as.numeric(hoge1[1,1]))
     } else {clusters = rep(1, nrow(dist_matrix))}
    } else {clusters = rep(1, nrow(dist_matrix))}
    names(clusters)=gene_clustering$labels
    cluster_ordering = paste(i, clusters, sep="_")
    names(cluster_ordering)=names(clusters)
    gene_clusters[[i]]=clusters[gene_clustering$order]
    genes_ordering[[i]]=cluster_ordering[gene_clustering$order]
    tmp_genes=tmp_genes[gene_clustering$order,]
    tmp_genes[tmp_genes>scale_max] = scale_max
    tmp_genes[tmp_genes<scale_min] = scale_min
    scaled_data=rbind(scaled_data, tmp_genes)
  }

  #heatmap annotation
  gene_clusters=unlist(gene_clusters)
  genes_ordering=unlist(genes_ordering)
  genes_ordering1=data.frame(Symbol=as.character(names(genes_ordering)))
  genes_ordering1[,1]=as.character(genes_ordering1[,1])
  rownames(genes_ordering1)=as.character(genes_ordering1[,1])
  rownames(colcondf)=as.character(colcondf[,1])
  colcondf[,1]=as.character(colcondf[,1])
  colcondf[,2]=as.character(colcondf[,2])
  annotation_row = dplyr::left_join(tibble::rownames_to_column(genes_ordering1),
                                    tibble::rownames_to_column(colcondf),
                                    by="rowname")
  rownames(annotation_row)=as.character(annotation_row[,1])

  gene_clusters1=data.frame(SubModule=gene_clusters)
  annotation_row=dplyr::left_join(annotation_row,
                                  tibble::rownames_to_column(gene_clusters1),
                                  by="rowname")
  rownames(annotation_row)=annotation_row[,1]
  annotation_row=annotation_row[,4:5]
  colnames(annotation_row)=c("Module", "SubModule")
  annotation_row[,2]=as.character(annotation_row[,2])


  EigenSubColors = c("magenta", "cyan")
  names(EigenSubColors) = c("1","2")

  names(Eigen_colors) = as.character(Eigen_colors)

  annotation_col = data.frame(
    Pseudotime=lineage,
    Seurat_Clusters=ident_annot,
    orig.ident=orig_ident_annot,
    lineageNb=lineage_name
  )

  annotation_colors = list(
    Pseudotime=lineage_colors,
    lineageNb=lineage_name_colors,
    Seurat_Clusters=ident.cols,
    orig.ident=orig.ident.cols,
    Module=Eigen_colors,
    SubModule=EigenSubColors
  )

  #define row gap points
  tmp = unique(genes_ordering)
  tmp1=c(1:length(tmp))
  for (i in c(length(tmp):1)){
    genes_ordering=gsub(tmp[i], tmp1[i],genes_ordering, fixed=TRUE)
  }
  gaps_row=utils::head(as.numeric(cumsum(table(as.numeric(genes_ordering)))), -1)

  cold = grDevices::colorRampPalette(c('#f7fcf0','#41b6c4','#253494','#081d58', '#081d58'))
  warm = grDevices::colorRampPalette(c('#ffffb2','#fecc5c','#e31a1c','#800026'))
  coldwarm = c(rev(cold(15)), warm(16))
  breaksList = seq(scale_min-0.1, scale_max+0.1, length=30)

  message("draw gene heatmap...")
  p = pheatmap::pheatmap(
    scaled_data,
    scale="none",
    cluster_cols=FALSE,
    cluster_rows=FALSE,
    show_colnames=FALSE,
    show_rownames=FALSE,
    annotation_col=annotation_col,
    annotation_row=annotation_row,
    annotation_colors=annotation_colors,
    fontsize = 7,
    gaps_col = gaps_col2,
    gaps_row = gaps_row,
    color=coldwarm,
    breaks = breaksList,
    silent = TRUE,
    main="pseudotime_DEGs"
  )

  message("export gene heatmap to file...")
  p_annotlegend = gtable::gtable_filter(p$gtable, pattern="annotation_legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p$gtable, pattern="legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p_heatlegend, pattern="annotation_legend", fixed=TRUE, invert=TRUE)
  p_main = gtable::gtable_filter(p$gtable, pattern="legend", invert=TRUE)

  file.name=paste(sample.name, "genes_pseudotime.png", sep='_')
  cowplot::save_plot(file = file.name,
                     cowplot::plot_grid(p_main, p_heatlegend, p_annotlegend,
                                        ncol=3, nrow=1, rel_widths = c(1, .1, .1), scale=1),
                     device="png",
                     units="in", dpi = 300, base_width = 20,
                     base_height = 10, limitsize=FALSE)

  message("generate gene clustering table...")

  kme1=WGCNA::signedKME(smooth_combine,me1)
  imc1=WGCNA::intramodularConnectivity(adj1,modcol[,2],scaleByMax=FALSE)
  tmp = cbind(imc1, kme1)
  clustering = dplyr::left_join(tibble::rownames_to_column(annotation_row),
                                tibble::rownames_to_column(tmp),
                                by="rowname")
  rownames(clustering) = clustering$rowname
  clustering = clustering[,2:ncol(clustering)]

  for (i in c(1:length(DE_gene_pseudoT))){
    colnames(DE_gene_pseudoT[[i]])=paste(colnames(DE_gene_pseudoT[[i]]), i, sep="_")
    clustering = dplyr::left_join(tibble::rownames_to_column(clustering),
                                  tibble::rownames_to_column(DE_gene_pseudoT[[i]]),
                                  by="rowname")
    rownames(clustering) = clustering$rowname
    clustering = clustering[,2:ncol(clustering)]
  }

  return(clustering)
}

utils::globalVariables(names = c("adj_min_pvalue", "smoothing"),
                       package = 'rDBEC',
                       add = TRUE)
#' pseudotimeDE_clustering2
#'
#' clustering and plotting DE genes identified by tradeSeq package by each pseudotime lineage.
#'
#' @param DE_res A list of DE gene table
#' @param object A Seurat object
#' @param pseudotime A slingshot object
#' @param sce A tradeSeq output object
#' @param smoothing logical. enables gene expression smoothing or not. Default=FALSE.
#' @param min.pct A minimum percent of expressed cells of each gene in each lineage
#' @param ident1 A cell identity of Seurat object, default is orig.ident
#' @param clustering.ident A cell cluster identity of Seurat object. Default=NULL
#' @param reduction.use A dimentional reduction method fro visulaization of Seurat object.
#' @param deepSplit A cutreeDymamic split parameter.
#' @param qvalue A qvalue threshold of DEGs
#' @param WGCNAthreads A WGCNA threads parameter.
#' @param sft_max A upper limit of sft threshold calculaton of WGCNA analysis
#' @param sft_limit A upper limit of sft threshold of WGCNA analysis
#' @param use_merge_clusters Whether use merged WGCNA modules or not. default=TRUE
#' @param merge_thres A parameter for merging WGCNA modules
#' @param scale_max A maximum scale value for heatmap drawing
#' @param scale_min A minimum scale value for heatmap drawing
#' @param row.names.gene Logical. Whether show gene name in pseudotime gene clustering heatmap. default=FALSE.
#' @param fontsize Size of gene name in pseudotime gene clustering heatmap. default=5.
#' @param sample.name A prefix file name for output files
#' @param col.palette A custom color palette for cell clustering. default=NULL
#'
#' @import Seurat
#' @import WGCNA
#' @importFrom tradeSeq predictCells
#' @importFrom stats cutree as.dist sd lm na.omit
#'
#' @rdname pseudotimeDE_clustering2
#' @return A data.frame of DEG clustering result and associated annotated heatmap
#' @export
#'
#'

pseudotimeDE_clustering2 <- function(DE_res,
                                    object,
                                    pseudotime,
                                    sce,
                                    smoothing=FALSE,
                                    min.pct=0.05,
                                    ident1="orig.ident",
                                    clustering.ident=NULL,
                                    reduction.use="FItSNE",
                                    deepSplit=4,
                                    qvalue=0.01,
                                    WGCNAthreads=24,
                                    sft_max=25,
                                    sft_limit=20,
                                    use_merge_clusters=TRUE,
                                    merge_thres=0.25,
                                    scale_max=2.5,
                                    scale_min=-2.5,
                                    row.names.gene=FALSE,
                                    fontsize=5,
                                    sample.name="./Pseudotime",
                                    col.palette=NULL){

  lineage=list()
  smooth=list()
  lineage_name=list()
  orig_ident_annot=list()
  ident_annot=list()
  if (object@version == "2.3.4" && is.null(clustering.ident)){
    clustering.ident=object@ident
  } else if (object@version >= "3.0" && is.null(clustering.ident)){
    clustering.ident=object@active.ident
  }

  cold = grDevices::colorRampPalette(c('#f7fcf0','#41b6c4','#253494','#081d58', '#081d58'))
  warm = grDevices::colorRampPalette(c('#ffffb2','#fecc5c','#e31a1c','#800026'))

  #smooth gene expression
  message("Filter DEGs...")
  sig_gene_pseudoT = DE_res[DE_res$adj_min_pvalue<=qvalue,]
  if (nrow(sig_gene_pseudoT)==0){
    stop("no significant DEGs. stop.")
  }

  #extract common root cells
  pseudotime=slingshot::slingPseudotime(pseudotime, na=TRUE)
  start_cells = rownames(pseudotime[rowSums(is.na(pseudotime))==0,])

  #filter genes by min.expressed pct of each lineages
  ALL_siggenes=NULL
  num_cells_expressed=NULL
  for (i in c(1:ncol(pseudotime))){
    lineage[[i]] <- pseudotime[!is.na(pseudotime[,i]),i]

    if (object@version == "2.3.4"){
    pseu1 = object@raw.data[,names(lineage[[i]])]
    pseu2 = apply(object@raw.data, 1, function(x){sum(x>0)})
    } else if (object@version >= "3.0"){
      pseu1 = object@assays$RNA@counts[,names(lineage[[i]])]
      pseu2 = apply(object@assays$RNA@counts, 1, function(x){sum(x>0)})

    }

    pseu3 = rownames(pseu1[pseu2>length(lineage[[i]])*min.pct,])
    ALL_siggenes = c(ALL_siggenes, pseu3)
    num_cells_expressed = cbind(num_cells_expressed, pseu2)
  }
  if (object@version == "2.3.4"){
  rownames(num_cells_expressed)=rownames(object@raw.data)
  } else if (object@version >= "3.0"){
    rownames(num_cells_expressed)=rownames(object@assays$RNA@counts)
  }
  colnames(num_cells_expressed)=paste("Ncells_expressed_lineage", c(1:ncol(num_cells_expressed)), sep="")
  ALL_siggenes=unique(ALL_siggenes)
  sig_gene_pseudoT = sig_gene_pseudoT[rownames(sig_gene_pseudoT) %in% ALL_siggenes,]
  if (nrow(sig_gene_pseudoT)==0){
    stop("no significant DEGs. Reconsider thresholds of DEGs.")
  } else {
    message(paste(nrow(sig_gene_pseudoT), "genes selected", sep=" "))
  }
  sig_gene_pseudoT = sig_gene_pseudoT[rownames(sig_gene_pseudoT) %in% rownames(sce),]

  if(smoothing){
  message("Smooth gene expression...")
  smoothed = tradeSeq::predictCells(models = sce, gene = rownames(sig_gene_pseudoT))
  } else {
  message("Gene expression smoothing is disabled. Use non-smoothed expression value...")
    if (object@version == "2.3.4"){
      smoothed = object@raw.data[rownames(sig_gene_pseudoT), rownames(pseudotime)]
    } else if (object@version >= "3.0"){
      smoothed = object@assays$RNA@counts[rownames(sig_gene_pseudoT), rownames(pseudotime)]
    }
  }
  message("Annotate cells...")
  for (i in c(1:ncol(pseudotime))){
      lineage[[i]] <- pseudotime[!is.na(pseudotime[,i]),i]

      #smooth[[i]] = smoothed[,colnames(smoothed) %in% names(lineage[[i]])]
      smooth[[i]] = smoothed[,names(lineage[[i]])]
      smooth[[i]] = as.data.frame(as.matrix(smooth[[i]]))
      smooth[[i]] = log2(smooth[[i]]+1)

      #extract annotations of cells of each lineage

      #orig.ident annotation and colors
      orig.ident.annot = object@meta.data[,ident1]
      names(orig.ident.annot) = rownames(object@meta.data)
      orig.ident.annot = as.factor(orig.ident.annot)
      #orig_ident_annot[[i]]=orig.ident.annot[names(orig.ident.annot) %in% colnames(smooth[[i]])]
      orig_ident_annot[[i]]=orig.ident.annot[colnames(smooth[[i]])]

      #cluster annotation
      ident.annot = clustering.ident
      ident_annot[[i]]=ident.annot[colnames(smooth[[i]])]

      #normalize pseudotime (from 0 to 1)
      #lineage[[i]] = lineage[[i]][names(lineage[[i]]) %in% colnames(smooth[[i]])]
      smooth[[i]] = smooth[[i]][ , order(lineage[[i]], decreasing = F)]
      orig_ident_annot[[i]] = orig_ident_annot[[i]][order(lineage[[i]], decreasing = F)]
      ident_annot[[i]] = ident_annot[[i]][order(lineage[[i]], decreasing = F)]

      #rename cells by lineage
      names(ident_annot[[i]])=paste(i, names(ident_annot[[i]]), sep="_")
      names(orig_ident_annot[[i]])=paste(i, names(orig_ident_annot[[i]]), sep="_")
      colnames(smooth[[i]])=paste(i, colnames(smooth[[i]]), sep="_")
      names(lineage[[i]])=paste(i, names(lineage[[i]]), sep="_")

      #lineage number annotation
      lineage_name[[i]]=as.character(rep(i, length(smooth[[i]])))
      names(lineage_name[[i]])=names(smooth[[i]])
      lineage_name[[i]] = lineage_name[[i]][order(lineage[[i]], decreasing = F)]
      names(lineage_name[[i]])=paste(i, names(lineage_name[[i]]), sep="_")

      lineage[[i]] = lineage[[i]][order(lineage[[i]], decreasing = F)]
      lineage[[i]] = log2(lineage[[i]]+1)
      hoge = names(lineage[[i]])
      lineage[[i]] = as.numeric(scale(lineage[[i]], center=min(lineage[[i]]),
                                      scale=(max(lineage[[i]])-min(lineage[[i]]))))
      names(lineage[[i]]) = hoge
    }


  message("Build cell annotations...")

  #specify orig.ident colors
  if (is.null(col.palette)){
  p1 = Seurat::DimPlot(object = object, reduction.use = reduction.use, group.by = ident1,
                       do.return = TRUE, vector.friendly = FALSE, pt.size = 0.3, no.legend=FALSE)
  } else if (object@version >= "3.0"){
    p1 = Seurat::DimPlot(object = object, reduction = reduction.use, group.by = ident1,
                         combine=TRUE, pt.size = 0.3)
  }

  orig_ident_build = ggplot2::ggplot_build(p1)
  orig_ident_build = orig_ident_build$data[[1]]
  orig_ident_build =  orig_ident_build[order(orig_ident_build$group), ]
  orig.ident.cols = unique(orig_ident_build$colour) # Get a vector of unique colors
  names(orig.ident.cols)=sort(as.character(unique(object@meta.data[,ident1])))

  #specify cluster colors
  if (object@version == "2.3.4"){
  p2 = Seurat::DimPlot(object = object, reduction.use = reduction.use,
                       do.return = TRUE, vector.friendly = FALSE, pt.size = 0.3, no.legend=FALSE)
  } else if (object@version >= "3.0"){
  p2 = Seurat::DimPlot(object = object, reduction = reduction.use,
                       combine=TRUE, pt.size = 0.3)
  }
  ident_build = ggplot2::ggplot_build(p2)
  ident_build = ident_build$data[[1]]
  ident_name = ident_build$group
  ident_name = ident_name-1
  names(ident_name)=rownames(object@meta.data)
  ident_name=as.factor(ident_name)
  levels(ident_name)=levels(clustering.ident)
  if(is.null(col.palette)){
  ident.cols = unique(ident_build[,c(2,6)])
  ident.cols = ident.cols[order(ident.cols$group),]
  ident.cols = ident.cols[,1]
  } else {
    if(object@version == "2.3.4"){
    ident.cols = col.palette[1:length(unique(object@ident))]
    } else if(object@version >= "3.0"){
    ident.cols = col.palette[1:length(unique(object@active.ident))]
    }
  names(ident.cols) = levels(clustering.ident)
  }
  #specify lineage colors
  lineage_name_colors = scales::hue_pal()(ncol(pseudotime))
  names(lineage_name_colors) = as.character(c(1:ncol(pseudotime)))

  #specify pseudotime colors
  lineage_colors = rev(grDevices::heat.colors(21))[-1]

  #merge cell annotations
  lineage_name=unlist(lineage_name)
  orig_ident_annot=unlist(orig_ident_annot)
  ident_annot=unlist(ident_annot)
  lineage=unlist(lineage)

  message("Merge each lineages and Cluster the genes by WGCNA pipeline...")

  #combine and scale expression matrix
  smooth_combine=smooth[[1]]
  if(length(smooth)>1){
    for (i in c(2:length(smooth))){
      smooth_combine = dplyr::full_join(tibble::rownames_to_column(as.data.frame(smooth_combine)),
                                        tibble::rownames_to_column(as.data.frame(smooth[[i]])),
                                        by = "rowname")
      rownames(smooth_combine)=smooth_combine$rowname
      smooth_combine = smooth_combine[,2:ncol(smooth_combine)]
    }
  }
  smooth_combine[is.na(smooth_combine)] = 0
  smooth_combine=smooth_combine[rownames(smooth_combine) %in% ALL_siggenes,]
  smooth_combine=t(smooth_combine)

  quiet <- function(x) {
    sink(tempfile())
    on.exit(sink())
    invisible(force(x))
  }

  quiet(WGCNA::allowWGCNAThreads(WGCNAthreads))

  #pick soft threshold
  powerseq=c(seq(1,sft_max,by=1))
  sft=quiet(WGCNA::pickSoftThreshold(smooth_combine, powerVector=powerseq, verbose=0))
  thre=data.frame(power=sft$fitIndices[,1], fit=-sign(sft$fitIndices[,3])*sft$fitIndices[,2])
  thre[,2]=thre[,2]-min(thre[,2])
  thre[,2]=abs(thre[,2]-max(thre[,2]))

  elbow_finder <- function(x_values, y_values) {
    # Max values to create line
    max_x_x <- max(x_values)
    max_x_y <- y_values[which.max(x_values)]
    max_y_y <- max(y_values)
    max_y_x <- x_values[which.max(y_values)]
    max_df <- data.frame(x = c(max_y_x, max_x_x), y = c(max_y_y, max_x_y))

    # Creating straight line between the max values
    fit <- stats::lm(max_df$y ~ max_df$x)

    # Distance from point to line
    distances <- c()
    for(i in 1:length(x_values)) {
      distances <- c(distances, abs(stats::coef(fit)[2]*x_values[i] - y_values[i] + stats::coef(fit)[1]) / sqrt(stats::coef(fit)[2]^2 + 1^2))
    }

    # Max distance point
    x_max_dist <- x_values[which.max(distances)]
    y_max_dist <- y_values[which.max(distances)]

    return(c(x_max_dist, y_max_dist))
  }

  thre1 = elbow_finder(thre[,1], thre[,2])
  pw1=thre1[1]

  if (pw1>=sft_limit){
  message(paste("Auto-detect soft threshold is ", pw1, " ,exceeds user-supplied limit. use user-supplied value", sep=""))
  pw1 = sft_limit
  }

  file.name=paste(sample.name, "softThreshold.png", sep='_')
  grDevices::png(file.name, width = 600, height = 400)
  graphics::par(mfrow=c(1,2))
  cex1=0.9;
  graphics::plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       xlab="Soft Threshold (power)", ylab="Scale Free Topology Model Fit, signed R^2", type="n",
       main=paste("Scale independence"))
  graphics::text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       labels=powerseq, cex=cex1,col="red")
  graphics::abline(h=0.90, col="red")
  graphics::abline(v=pw1, col="cyan")
  graphics::plot(sft$fitIndices[,1],sft$fitIndices[,5],
       xlab="Soft Threshold (power)", ylab="Mean Connectivity", type="n",
       main=paste("Mean connectivity"))
  graphics::text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powerseq, cex=cex1, col="red")
  grDevices::dev.off()

  #calculate topological overlap matrix
  adj1=quiet(WGCNA::adjacency(smooth_combine,power=pw1))
  convec=quiet(WGCNA::softConnectivity(smooth_combine,
                                 corFnc = "cor", corOptions = "use = 'p'",type = "unsigned",
                                 power =pw1,blockSize = 1500,
                                 minNSamples = NULL,verbose = 2, indent = 0))
  stom1=quiet(WGCNA::TOMsimilarity(adj1))
  dissim=1-stom1

  # clustering
  genetree=quiet(flashClust::flashClust(as.dist(dissim), method="average"))

  # detection of modules
  merge_thres=merge_thres      # often 0.25
  dmd1=quiet(dynamicTreeCut::cutreeDynamic(dendro=genetree, distM=dissim,
                                     deepSplit=deepSplit))
  dc1=WGCNA::labels2colors(dmd1)

  # merging of initial modules
  melist=WGCNA::moduleEigengenes(smooth_combine, colors=dc1)
  mes=melist$eigengenes
  mediss=1-WGCNA::cor(mes)
  metree=flashClust::flashClust(as.dist(mediss), method="average")
  merge=WGCNA::mergeCloseModules(smooth_combine,dc1,cutHeight=merge_thres,
                                 relabel=TRUE, verbose=3)

  while (length(unique(merge$colors))>=15){
  message(paste("more than 15 modules are identified, reset merge_thres as ", merge_thres, ".", sep=""))
  merge_thres = merge_thres+0.01
  merge=WGCNA::mergeCloseModules(smooth_combine,dc1,cutHeight=merge_thres,
                                 relabel=TRUE, verbose=2)
  if (merge_thres >= 0.4) break
  }

  colorOrder=c("grey", standardColors(50))
  if (use_merge_clusters){
   if (length(unique(merge$colors))>3){
   #modcol=merge$colors
   modcol=data.frame(original=dc1, merge=merge$colors)
   modlab=match(modcol, colorOrder)-1
   modme=merge$newMEs
   file.name=paste(sample.name, "Dendrogram.png", sep='_')
   grDevices::png(file.name, width = 600, height = 400)
   graphics::par(mfrow=c(1,1))
   WGCNA::plotDendroAndColors(genetree,modcol, c("original", "merged"),
                             dendroLabels=FALSE, hang=0.03,addGuide=TRUE, guideHang=0.05,
                             main="Gene dendrogram and module colors")
   grDevices::dev.off()
   } else {
   message("warning: merged module number is less than 3, use original un-merged modules")
   modcol=data.frame(merge=dc1)
   modlab=match(modcol, colorOrder)-1
   modme=merge$oldMEs
   file.name=paste(sample.name, "Dendrogram.png", sep='_')
   grDevices::png(file.name, width = 600, height = 400)
   graphics::par(mfrow=c(1,1))
   WGCNA::plotDendroAndColors(genetree,modcol, "original",
                             dendroLabels=FALSE, hang=0.03,addGuide=TRUE, guideHang=0.05,
                             main="Gene dendrogram and module colors")
   grDevices::dev.off()
   }
  } else {
    message("merging modules were disabled. Original un-merged modules were used.")
    modcol=data.frame(merge=dc1)
    modlab=match(modcol, colorOrder)-1
    modme=merge$oldMEs
    file.name=paste(sample.name, "Dendrogram.png", sep='_')
    grDevices::png(file.name, width = 600, height = 400)
    graphics::par(mfrow=c(1,1))
    WGCNA::plotDendroAndColors(genetree,modcol, "original",
                               dendroLabels=FALSE, hang=0.03,addGuide=TRUE, guideHang=0.05,
                               main="Gene dendrogram and module colors")
    grDevices::dev.off()
  }

  # heatmap of eigengene
  if (use_merge_clusters){
   if (length(unique(merge$colors))>3){
   me1=WGCNA::moduleEigengenes(smooth_combine,merge$colors)$eigengenes
   meord=WGCNA::orderMEs(me1)
   file.name=paste(sample.name, "Dendrogram_Eigengenes.png", sep='_')
   grDevices::png(file.name, width = 400, height = 600)
   graphics::par(mfrow=c(1,2))
   WGCNA::plotEigengeneNetworks(meord, "Eigengene dendrogram",
                               marDendro=c(0,4,2,2), marHeatmap=c(3,4,2,2))
   grDevices::dev.off()
   } else {
   me1=WGCNA::moduleEigengenes(smooth_combine,dc1)$eigengenes
   meord=WGCNA::orderMEs(me1)
   message("do not plot eigengene dendrogram because number of module is less than 3")
   }
  } else {
    if (length(dc1)>3){
      me1=WGCNA::moduleEigengenes(smooth_combine,dc1)$eigengenes
      meord=WGCNA::orderMEs(me1)
      file.name=paste(sample.name, "Dendrogram_Eigengenes.png", sep='_')
      grDevices::png(file.name, width = 400, height = 600)
      graphics::par(mfrow=c(1,2))
      WGCNA::plotEigengeneNetworks(meord, "Eigengene dendrogram",
                                   marDendro=c(0,4,2,2), marHeatmap=c(3,4,2,2))
      grDevices::dev.off()
    } else {
      me1=WGCNA::moduleEigengenes(smooth_combine,dc1)$eigengenes
      meord=WGCNA::orderMEs(me1)
      message("do not plot eigengene dendrogram because number of module is less than 3")
    }
  }

  #draw Eigengene heatmap by pseudotime
  message("Draw eigengene pseudotime heatmap...")
  temp = t(meord)
  temp = temp[c(1:nrow(temp)-1),,drop=F]

  annotation_col = data.frame(
    Pseudotime=lineage,
    Seurat_Clusters=ident_annot,
    orig.ident=orig_ident_annot,
    lineageNb=lineage_name
  )

  Eigengenes = rownames(temp)
  names(Eigengenes) = rownames(temp)

  annotation_row = data.frame(Eigengenes=Eigengenes)
  rownames(annotation_row)=rownames(temp)

  Eigen_colors=gsub("ME", "", rownames(temp))
  names(Eigen_colors)=rownames(temp)

  annotation_colors = list(
    Pseudotime=lineage_colors,
    lineageNb=lineage_name_colors,
    Seurat_Clusters=ident.cols,
    orig.ident=orig.ident.cols,
    Eigengenes=Eigen_colors
  )

  gaps_col=NULL
  if(length(unique(annotation_col$lineageNb))>1){
  gaps_col = utils::head(as.numeric(cumsum(table(as.numeric(annotation_col$lineageNb)))), -1)
  #root_cells = nrow(stats::na.omit(pseudotime))
  #gaps_col1 = gaps_col + root_cells
  #gaps_col2 = root_cells
  # for (i in c(1:length(gaps_col))){
  #  gaps_col2=c(gaps_col2, gaps_col[i])
  #  gaps_col2=c(gaps_col2, gaps_col1[i])
  # }
  }

  temp=temp[!apply(temp,1,sd)==0,,drop=F]
  temp=Matrix::t(scale(Matrix::t(temp),center=TRUE))
  temp=temp[is.na(rownames(temp)) == FALSE,,drop=F]
  temp[is.nan(temp)] = 0
  temp[temp>scale_max] = scale_max
  temp[temp<scale_min] = scale_min
  bks = seq(scale_min-0.1, scale_max+0.1, by = 0.1)
  hmcols = viridis::inferno(length(bks))

  p = pheatmap::pheatmap(
    as.data.frame(temp),
    scale="none",
    cluster_cols=FALSE,
    cluster_rows=FALSE,
    show_colnames=FALSE,
    show_rownames=TRUE,
    annotation_col=annotation_col,
    annotation_row=annotation_row,
    annotation_colors=annotation_colors,
    annotation_names_row = FALSE,
    gaps_col = gaps_col,
    gaps_row = utils::head(as.numeric(cumsum(table(1:length(annotation_row$Eigengenes)))), -1),
    color=hmcols,
    breaks = bks,
    silent=TRUE,
    main="pseudotime_Eigengenes"
  )
  p_annotlegend = gtable::gtable_filter(p$gtable, pattern="annotation_legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p$gtable, pattern="legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p_heatlegend, pattern="annotation_legend", fixed=TRUE, invert=TRUE)
  p_main = gtable::gtable_filter(p$gtable, pattern="legend", invert=TRUE)

  file.name=paste(sample.name, "Eigengenes_pseudotime.png", sep='_')
  cowplot::save_plot(file = file.name,
                     cowplot::plot_grid(p_main, p_heatlegend, p_annotlegend,
                                        ncol=3, nrow=1, rel_widths = c(1, .1, .1), scale=1),
                     device="png",
                     units="in", dpi = 300, base_width = 20,
                     base_height = 10, limitsize=FALSE)

  #sub-clusterings within WGCNA modules and draw heatmap
  if (use_merge_clusters){
   if (length(unique(merge$colors))>3){
   colcondf=data.frame(Symbol=colnames(smooth_combine), Color=modcol[,2])
   } else {
   colcondf=data.frame(Symbol=colnames(smooth_combine), Color=modcol[,1])
   }
  } else {
      colcondf=data.frame(Symbol=colnames(smooth_combine), Color=modcol[,1])
  }
  rownames(colcondf)=as.character(colcondf[,1])
  gene_clusters=list()
  genes_ordering=list()
  silhouette=list()
  scaled_data=NULL
  #object_tmp = object@assays$RNA@counts
  #object_tmp = Seurat::CreateSeuratObject(object_tmp)
  #object_tmp = Seurat::NormalizeData(object_tmp, scale.factor = 1000000)
  #object_tmp = Seurat::ScaleData(object_tmp, features = rownames(object_tmp@assays$RNA@counts),
  #                               vars.to.regress="nCount_RNA")

  for (i in c(1:length(Eigen_colors))){
    tmp_genes=NULL
    for (j in c(1:length(smooth))){
      tmp2 = paste("^", j,"_", sep="")

      if (object@version == "2.3.4"){
      #hoge = object@scale.data[rownames(colcondf[colcondf$Color == Eigen_colors[i],]),
      #                         gsub(tmp2, "", colnames(smooth[[j]]))]
      hoge = smooth_combine[rownames(colcondf[colcondf$Color == Eigen_colors[i],]),
                            gsub(tmp2, "", colnames(smooth[[j]]))]
      } else if (object@version >= "3.0"){
        #hoge = Seurat::GetAssayData(object, assay = "RNA", slot = "scale.data")
        hoge = smooth_combine[rownames(colcondf[colcondf$Color == Eigen_colors[i],]),
                                 gsub(tmp2, "", colnames(smooth[[j]]))]
      }

      colnames(hoge)=colnames(smooth[[j]])
      tmp_genes=cbind(tmp_genes, hoge)
    }
    tmp_genes[tmp_genes>10] = 10
    tmp_genes[tmp_genes<-10] = -10

    MyhclustFUN = function(x,k){
      dist_matrix <- stats::as.dist((1 - WGCNA::cor(Matrix::t(x), method="pearson", nThreads=WGCNAthreads))/2)
      dist_matrix[is.na(dist_matrix)] <- 1
      return(list(cluster=stats::cutree(gene_clustering, k)))
    }
    silhouette[[i]] =  try(factoextra::fviz_nbclust(tmp_genes, MyhclustFUN,
                                                    method="silhouette",
                                                    k.max=5), silent=TRUE)

    #clustering
    dist_matrix <- stats::as.dist((1 - WGCNA::cor(Matrix::t(tmp_genes), method="pearson", nThreads=WGCNAthreads/2))/2)
    dist_matrix[is.na(dist_matrix)] <- 1
    gene_clustering = flashClust::flashClust(dist_matrix, method="ward")

    if (class(silhouette[[i]]) != "try-error" && class(silhouette[[i]]) != "NULL") {
      hoge1 = silhouette[[i]][[1]][order(silhouette[[i]][[1]][,2], decreasing=T),]
      if(as.numeric(hoge1[1,1])>1){
        clusters = stats::cutree(gene_clustering,
                                 k = as.numeric(hoge1[1,1]))
      } else {clusters = rep(1, nrow(dist_matrix))}
    } else {clusters = rep(1, nrow(dist_matrix))}
    names(clusters)=gene_clustering$labels
    cluster_ordering = paste(i, clusters, sep="_")
    names(cluster_ordering)=names(clusters)
    gene_clusters[[i]]=clusters[gene_clustering$order]
    genes_ordering[[i]]=cluster_ordering[gene_clustering$order]
    tmp_genes=tmp_genes[gene_clustering$order,]
    #tmp_genes[tmp_genes>scale_max] = scale_max
    #tmp_genes[tmp_genes<scale_min] = scale_min
    scaled_data=rbind(scaled_data, tmp_genes)
  }

  #heatmap annotation
  gene_clusters=unlist(gene_clusters)
  genes_ordering=unlist(genes_ordering)
  genes_ordering1=data.frame(Symbol=as.character(names(genes_ordering)))
  genes_ordering1[,1]=as.character(genes_ordering1[,1])
  rownames(genes_ordering1)=as.character(genes_ordering1[,1])
  rownames(colcondf)=as.character(colcondf[,1])
  colcondf[,1]=as.character(colcondf[,1])
  colcondf[,2]=as.character(colcondf[,2])
  annotation_row = dplyr::left_join(tibble::rownames_to_column(genes_ordering1),
                                    tibble::rownames_to_column(colcondf),
                                    by="rowname")
  rownames(annotation_row)=as.character(annotation_row[,1])

  gene_clusters1=data.frame(SubModule=gene_clusters)
  annotation_row=dplyr::left_join(annotation_row,
                                  tibble::rownames_to_column(gene_clusters1),
                                  by="rowname")
  rownames(annotation_row)=annotation_row[,1]
  annotation_row=annotation_row[,4:5]
  colnames(annotation_row)=c("Module", "SubModule")
  annotation_row[,2]=as.character(annotation_row[,2])


  EigenSubColors = c("magenta", "cyan", "purple", "brown", "black")
  names(EigenSubColors) = c("1","2", "3", "4", "5")
  EigenSubColors=EigenSubColors[names(EigenSubColors) %in% unique(annotation_row[,2])]

  names(Eigen_colors) = as.character(Eigen_colors)

  annotation_col = data.frame(
    Pseudotime=lineage,
    Seurat_Clusters=ident_annot,
    orig.ident=orig_ident_annot,
    lineageNb=lineage_name
  )

  annotation_colors = list(
    Pseudotime=lineage_colors,
    lineageNb=lineage_name_colors,
    Seurat_Clusters=ident.cols,
    orig.ident=orig.ident.cols,
    Module=Eigen_colors,
    SubModule=EigenSubColors
  )

  #define row gap points
  tmp = unique(genes_ordering)
  tmp1=c(1:length(tmp))
  for (i in c(length(tmp):1)){
    genes_ordering=gsub(tmp[i], tmp1[i],genes_ordering, fixed=TRUE)
  }
  gaps_row=utils::head(as.numeric(cumsum(table(as.numeric(genes_ordering)))), -1)

  cold = grDevices::colorRampPalette(c('#f7fcf0','#41b6c4','#253494','#081d58', '#081d58'))
  warm = grDevices::colorRampPalette(c('#ffffb2','#fecc5c','#e31a1c','#800026'))
  coldwarm = c(rev(cold(15)), warm(16))
  breaksList = seq(scale_min-0.1, scale_max+0.1, length=30)

  message("draw gene heatmap...")
  p = pheatmap::pheatmap(
    scaled_data,
    scale="none",
    cluster_cols=FALSE,
    cluster_rows=FALSE,
    show_colnames=FALSE,
    show_rownames=row.names.gene,
    annotation_col=annotation_col,
    annotation_row=annotation_row,
    annotation_colors=annotation_colors,
    fontsize = fontsize,
    gaps_col = gaps_col,
    gaps_row = gaps_row,
    color=coldwarm,
    silent = TRUE,
    breaks = breaksList,
    main="pseudotime_DEGs"
  )

  message("export gene heatmap to file...")
  p_annotlegend = gtable::gtable_filter(p$gtable, pattern="annotation_legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p$gtable, pattern="legend", fixed=TRUE)
  p_heatlegend = gtable::gtable_filter(p_heatlegend, pattern="annotation_legend", fixed=TRUE, invert=TRUE)
  p_main = gtable::gtable_filter(p$gtable, pattern="legend", invert=TRUE)

  file.name=paste(sample.name, "genes_pseudotime.png", sep='_')
  cowplot::save_plot(file = file.name,
            cowplot::plot_grid(p_main, p_heatlegend, p_annotlegend,
                      ncol=3, nrow=1, rel_widths = c(1, .1, .1), scale=1),
            device="png",
            units="in", dpi = 300, base_width = 20,
            base_height = 10, limitsize=FALSE)

  message("generate gene clustering table...")

  kme1=WGCNA::signedKME(smooth_combine,me1)
  if (use_merge_clusters){
   if (length(unique(merge$colors))>3){
   imc1=WGCNA::intramodularConnectivity(adj1,modcol[,2],scaleByMax=FALSE)
   } else {
   imc1=WGCNA::intramodularConnectivity(adj1,modcol[,1],scaleByMax=FALSE)
   }
  } else {
   imc1=WGCNA::intramodularConnectivity(adj1,modcol[,1],scaleByMax=FALSE)
  }
  tmp = cbind(imc1, kme1)
  clustering = dplyr::left_join(tibble::rownames_to_column(annotation_row),
                                tibble::rownames_to_column(tmp),
                                by="rowname")
  rownames(clustering) = clustering$rowname
  clustering = clustering[,2:ncol(clustering)]

  #add p value and fold-change
  clustering = dplyr::left_join(tibble::rownames_to_column(clustering),
                                  tibble::rownames_to_column(DE_res),
                                  by="rowname")
  rownames(clustering) = clustering$rowname
  clustering = clustering[,2:ncol(clustering)]

  #add number of cells expressed in each lineage
  clustering = dplyr::left_join(tibble::rownames_to_column(clustering),
                                tibble::rownames_to_column(as.data.frame(num_cells_expressed)),
                                by="rowname")
  rownames(clustering) = clustering$rowname
  clustering = clustering[,2:ncol(clustering)]

  return(clustering)
}
