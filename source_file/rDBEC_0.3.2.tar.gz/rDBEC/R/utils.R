#' tableread_fast_sparse
#'
#' fast read count data table as sparse matrix
#'
#' @param x A list of PASS to the tab-delimitered scRNA-seq count data files
#' @param sep A delimiter of count data table
#' @param header Logical. Whether count data file contains header (Cell IDs) or not
#'
#'
#' @rdname tableread_fast_sparse
#' @return A genes x cells count sparse matrix
#' @export
#'

tableread_fast_sparse = function(x, sep="\t", header=TRUE){
  tmp = data.table::fread(x, header=header, sep=sep, quote="")
  tmp = as.data.frame(tmp)
  rownames(tmp) = tmp[,1]
  tmp = tmp[,2:ncol(tmp)]
  tmp = as.matrix(tmp)
  tmp = Matrix::Matrix(tmp, sparse = TRUE)
  return(tmp)
}

#' quiet
#'
#' supress messages and prints from any of the functions
#'
#' @param x function
#'
#' @rdname quiet
#' @export
#'
quiet <- function(x) {
  sink(tempfile())
  on.exit(sink())
  invisible(force(x))
}

#' tableread_fast_hashtag
#'
#' fast read hashtag count data table as dense matrix
#'
#' @param x A list of PASS to the tab-delimitered scRNA-seq count data files
#' @param sep A delimiter of count data table
#' @param header Logical. Whether count data file contains header (Cell IDs) or not
#'
#'
#' @rdname tableread_fast_hashtag
#' @return A hashtag x cells count data frame
#' @export
#'

tableread_fast_hashtag = function(x, sep="\t", header=TRUE){
  tmp = data.table::fread(x, header=header, sep=sep, quote="")
  tmp = as.data.frame(tmp)
  return(tmp)
}

#' tableread_fast
#'
#' fast read count data table as dense matrix
#'
#' @param x A list of PASS to the tab-delimitered scRNA-seq count data files
#' @param sep A delimiter of count data table
#' @param header Logical. Whether count data file contains header (Cell IDs) or not
#'
#'
#' @rdname tableread_fast
#' @return A genes x cells count data frame
#' @export
#'

tableread_fast = function(x, sep="\t", header=TRUE){
  tmp = data.table::fread(x, header=TRUE, sep="\t", quote="")
  tmp = as.data.frame(tmp)
  rownames(tmp) = tmp[,1]
  tmp = tmp[,2:ncol(tmp)]
  return(tmp)
}

#' hclust_pearson_fast
#'
#' fast calculation of hclust based on pearson correlation coefficient distances
#'
#' @param x matrix
#' @param k number of cutree clusters
#'
#'
#' @rdname hclust_pearson_fast
#' @return A cutree object
#' @export
#'
hclust_pearson_fast = function(x,k){
  dist_matrix <- stats::as.dist((1 - WGCNA::cor(Matrix::t(x), use = "pairwise.complete.obs", method="pearson", nThreads=6))/2)
  dist_matrix[is.na(dist_matrix)] <- 1
  gene_clustering = flashClust::flashClust(dist_matrix, method="ward")
  return(list(cluster=stats::cutree(gene_clustering, k)))
}
